# 行星物语

微信小程序单页 3D 地球体验。核心不是传统地图工具，而是“可探索的地球 + 此刻时间 + 诗意沉浸”：用户可以旋转地球、搜索国家或城市、查看国家信息，进入禅定模式后播放诗句和音乐，并可进入登月旅程。

## 当前入口

- 小程序入口：`miniprogram/pages/gl/index`
- 页面标题：`行星物语`
- 项目配置：`project.config.json`
- 云环境 ID：`cloud1-1g6316vt2769d82c`

## 主要目录

- `miniprogram/pages/gl/`：3D 地球页面、WebGL 渲染、交互、禅定模式、登月模式。
- `miniprogram/assets/data/`：国家、城市、诗句等本地兜底数据。
- `miniprogram/assets/flags/`：国家信息面板右上角国旗图集，随小程序代码包发布。
- `cloudfunctions/`：可部署的云函数，主要用于诗句、城市、国家信息等云端数据。
- `tools/`：Node.js 小测试和辅助脚本。

## 本地开发

1. 用微信开发者工具打开项目根目录。
2. 如果依赖缺失，分别安装根目录和小程序目录依赖：

```bash
npm install
cd miniprogram && npm install
```

3. 在微信开发者工具中执行“构建 npm”，再编译小程序。

`tools/dev-server.js` 只是静态文件服务，只能检查资源是否能被读取，不能替代微信小程序运行环境。

## 验证

当前没有统一的 `npm test`。已有的策略测试可以这样运行：

```bash
for f in tools/*.test.cjs; do node "$f"; done
```

这组测试覆盖部分渲染循环、标签布局、性能策略、贴图恢复和运行诊断逻辑。视觉和触摸体验仍以微信开发者工具模拟器或真机预览为准。

## 产品结构

普通模式：
- 顶部工具栏：语言、当前时间、设置、搜索、禅定入口。
- 搜索面板：支持国家和城市搜索，选中后飞向对应位置并打开国家信息。
- 国家面板：展示国旗、首都、面积、人口、GDP，并保持画布可继续旋转。

禅定模式：
- 隐藏普通工具栏，启动诗句、音乐、自动缓慢旋转和沉浸式视觉。
- “定”按钮切换诗句/音乐预设。
- 右下角月亮入口进入登月旅程。

登月模式：
- 接管普通交互，播放登月时间线、歌词和月球相关视觉。
- 右上角时间信息支持长按显示/隐藏。

## 数据与云函数

小程序优先使用本地兜底数据，能访问云环境时再使用云函数或数据库：

- `poetrySets`：读取/更新 `poetry_sets` 诗句预设。
- `citiesFetch` / `citiesImport`：读取和导入城市数据。
- `countryMeta`：读取/更新 `country_meta` 国家信息。
- `poetryCalib`：诗句校准相关能力。
- `quickstartFunctions`：云开发模板残留函数，不是核心产品路径。

如果云端数据或贴图不可用，先确认微信开发者工具云环境、云函数部署状态和本地兜底资源，再改业务逻辑。

开发者工具和 PC 客户端默认不请求云贴图（`forceCloudTextures: false`），使用 `miniprogram/assets/textures/preview-*` 的 512×256 本地预览图。它们分别由仓库根目录的 `earth.jpg`、`earth_day8k.webp`、`earth_night.webp`、`cloud.webp` 缩小生成，合计约 260 KiB。手机端仍走原来的云端高清贴图路径。

此前桌面兜底只有 1×1 占位图，导致地球无纹理，并被健康检查反复判为坏图、重载同一占位图；刷新无法解决。2026-09-09 已替换桌面预览资源，自动测试通过；因 Mac 锁屏，修正后的模拟器画面验收仍待完成。

## 本地图集资源

国家面板的国旗使用 `miniprogram/assets/flags/flags-sprite.png` 和 `miniprogram/pages/gl/flag-sprite.js` 的映射表。图集是本地 PNG 资源，随小程序包上传，不需要云存储；不要改成本地 WebP，真机客户端对小程序包内 WebP 渲染不稳定。
