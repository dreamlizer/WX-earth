const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createScopedThreejs } = require('../miniprogram/node_modules/threejs-miniprogram');

function load(file, names, dependencies = {}) {
  const filename = path.join(__dirname, '../miniprogram/pages/gl', file);
  const source = fs.readFileSync(filename, 'utf8')
    .replace(/^import[\s\S]*?;\s*$/gm, '')
    .replace(/export (class|function|const) /g, '$1 ');
  const context = { module: { exports: {} }, console, setTimeout, clearTimeout, ...dependencies };
  vm.runInNewContext(source + `\nmodule.exports = { ${names} };`, context, { filename });
  return context.module.exports;
}

function testRouteExclusion() {
  const { AppEngine } = load('app-engine.js', 'AppEngine', {
    APP_CFG: {}, getSystemInfo: () => ({}), createTouchState: () => ({}), TWEEN: {}
  });
  const engine = new AppEngine();
  let originalEntries = 0;
  let trialEntries = 0;
  engine.state = { page: { data: { zenMode: true } } };
  engine.moonMgr = { _entering: false, _exiting: false, isActive: () => false,
    enter() { originalEntries++; } };
  engine.moonTrial = { isActive: () => false, enter() { trialEntries++; } };
  assert.equal(typeof engine.enterMoonTrial, 'function', 'engine must expose the parallel trial entry');
  for (const flag of ['_entering', '_exiting']) {
    engine.moonMgr[flag] = true;
    engine.enterMoonTrial();
    assert.equal(trialEntries, 0, 'original loading/exit must exclude the trial');
    engine.moonMgr[flag] = false;
  }
  engine.moonMgr.isActive = () => true;
  engine.enterMoonTrial();
  assert.equal(trialEntries, 0);
  engine.moonMgr.isActive = () => false;
  engine.enterMoonTrial();
  assert.equal(trialEntries, 1);
  engine.moonTrial.isActive = () => true;
  engine.enterMoonVoyage();
  assert.equal(originalEntries, 0, 'trial loading/playback must exclude the original');
  assert.equal(engine.isMoonVoyageActive(), true, 'trial must lock ordinary globe interactions');
  let exited = 0;
  let resumed = 0;
  engine.moonTrial.exit = (updatePage, resume) => {
    assert.equal(updatePage, true);
    assert.equal(resume, false, 'background cancellation must not resume audio');
    exited++;
  };
  engine.moonTrial.resumeZen = () => { resumed++; };
  engine.setPaused(true);
  assert.equal(exited, 1, 'backgrounding must cancel the trial before pausing rendering');
  engine.setPaused(false);
  assert.equal(resumed, 1, 'foregrounding must restore deferred zen state');
}

async function testTrialLifecycle() {
  const views = [];
  let audioTime = 0;
  let resumed = 0;
  let suspended = 0;
  const poetryRestores = [];
  const { MoonTrial } = load('moon-trial.js', 'MoonTrial', {
    createMoonTrialScene() {
      let resolve, reject;
      const ready = new Promise((ok, fail) => { resolve = ok; reject = fail; });
      const view = { ready, resolve, reject, disposeCount: 0, samples: [],
        update(t) { this.samples.push(t); }, render() {},
        dispose() { this.disposeCount++; } };
      views.push(view);
      return view;
    }, TRIAL_DURATION_SEC: 104,
    playPoetry(...args) { poetryRestores.push(args); }
  });
  const original = { zenMode: true, currentPreset: 103, poetryA: { text: 'kept' } };
  const page = { data: { ...original }, __zenPreset: 103, writes: 0,
    setData(updates) { this.writes++; Object.assign(this.data, updates); },
    __getZenModeMgr: () => ({ closeList() {} }),
    __getZenMgr: () => ({ suspend() { suspended++; }, resume() { resumed++; } }),
    __getPoetryMgr: () => ({ getIndex: () => 7, stop() {} }), showMoonToast() {} };
  const trial = new MoonTrial({}, page, class { start() { return Promise.resolve(); } getTime() { return audioTime; } fadeOut() {} dispose() {} });
  const pending = trial.enter();
  assert.equal(trial.isActive(), true, 'loading must own the lock immediately');
  await trial.enter();
  assert.equal(views.length, 1, 'repeated tap must not allocate another scene');
  trial.exit();
  views[0].resolve();
  await pending;
  assert.equal(trial.isActive(), false, 'late texture completion cannot revive cancelled trial');
  assert.equal(views[0].disposeCount, 1);

  const second = trial.enter();
  views[1].resolve();
  await second;
  trial.render({}, 0.46, 1000);
  audioTime = 5;
  trial.render({}, 0.46, 6000);
  assert.equal(views[1].samples.at(-1), 5);
  audioTime = 104;
  trial.render({}, 0.46, 11000);
  assert.equal(trial.isActive(), false, 'audio reaching the ending must return automatically');
  assert.equal(page.data.zenMode, true);
  assert.equal(page.data.currentPreset, 103);
  assert.equal(page.__zenPreset, 103);
  assert.equal(page.data.poetryA, original.poetryA, 'trial does not replace the running zen timeline');

  const failed = trial.enter();
  views[2].reject(new Error('texture failed'));
  await failed;
  assert.equal(trial.isActive(), false, 'load failure must release input and hide trial UI');
  assert.equal(page.data.moonTrialActive, false);
  const unloading = trial.enter();
  trial.dispose();
  const writes = page.writes;
  views[3].resolve();
  await unloading;
  assert.equal(page.writes, writes, 'unload must not publish late page updates');
  assert.equal(views[3].disposeCount, 1);
  assert.equal(suspended, 4);
  assert.equal(resumed, 3, 'unload must not resume zen audio');
  assert.equal(poetryRestores[0][1], 103);
  assert.equal(poetryRestores[0][2], 7, 'return resumes the saved poem');

  const backgroundTrial = new MoonTrial({}, page, class {
    start() { return Promise.resolve(); } getTime() { return 0; } fadeOut() {} dispose() {}
  });
  const backgroundEntry = backgroundTrial.enter();
  views[4].resolve();
  await backgroundEntry;
  backgroundTrial.exit(true, false);
  assert.equal(resumed, 3);
  backgroundTrial.resumeZen();
  backgroundTrial.resumeZen();
  assert.equal(resumed, 4, 'foreground restores a deferred session only once');

  const stalledEntry = backgroundTrial.enter();
  views[5].resolve();
  await stalledEntry;
  backgroundTrial.render({}, 0.46, 1000);
  backgroundTrial.render({}, 0.46, 16001);
  assert.equal(backgroundTrial.isActive(), false, 'stalled audio must release the locked scene');
}

function testRenderingIsolation() {
  const { createSceneUpdater } = load('scene-updater.js', 'createSceneUpdater');
  let trialFrames = 0;
  const forbidden = () => { throw new Error('original scene must not advance during trial'); };
  const updater = createSceneUpdater({ refs: {}, perfMonitor: { update: () => 0.016 },
    tweener: { update: forbidden }, lighting: { updateDirLight: forbidden },
    renderMoonTrial() { trialFrames++; return true; } });
  updater.update();
  assert.equal(trialFrames, 1);
}

async function testGeometryAndOwnership() {
  const images = [];
  const THREE = createScopedThreejs({ width: 390, height: 844,
    createImage() { const image = {}; images.push(image); return image; } });
  const { createMoonTrialScene } = load('moon-trial-scene.js', 'createMoonTrialScene', {
    fixTexture() {},
    wx: { getFileSystemManager: () => ({ readFile({filePath, success}) {
      const bytes = fs.readFileSync(path.join(__dirname, '../miniprogram', filePath));
      success({data: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset+bytes.byteLength)});
    } }) }
  });
  const view = createMoonTrialScene(THREE, false);
  assert.equal(view.scene.background, null, 'transparent canvas background must preserve native page overlays');
  images.forEach(image => image.dispatchEvent({ type: 'load' }));
  await view.ready;
  const moon = view.scene.getObjectByName('TRIAL_MOON');
  const earth = view.scene.getObjectByName('TRIAL_EARTH');
  const sun = view.scene.getObjectByName('TRIAL_SUN');
  const ambient = view.scene.children.find(object => object.isAmbientLight);
  assert.ok(sun?.isDirectionalLight, 'Earth and Moon need a shared parallel sunlight source');
  assert.equal(sun.castShadow, false, 'surface day/night must not allocate a shadow-map pass');
  assert.ok(ambient.intensity / sun.intensity < 0.05, 'fill light must not erase the lunar night side');
  assert.ok(earth.material.isMeshLambertMaterial && moon.material.isMeshLambertMaterial,
    'both globes must respond to the same scene lighting');
  const sunlight = sun.position.clone().sub(sun.target.position).normalize();
  const originalSunPosition = sun.position.clone();
  const moonPhases = [];
  assert.equal(moon.material.transparent, false, 'occluder must write solid depth');
  assert.equal(moon.material.depthWrite, true);
  assert.equal(earth.material.depthTest, true);
  const originalEarthPosition = earth.position.clone();
  for (const aspect of [0.45, 0.5625, 1.78]) {
    const coverage = [];
    for (let t = 49; t <= 65; t += 0.1) {
      view.update(t, aspect);
      view.scene.updateMatrixWorld(true);
      view.camera.updateMatrixWorld(true);
      let blocked = 0, total = 0;
      const center = earth.position.clone().project(view.camera);
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(view.camera.quaternion);
      const up = new THREE.Vector3(0, 1, 0).applyQuaternion(view.camera.quaternion);
      // Sample rays over the Earth's apparent disc, including partial occlusion.
      for (let x = -4; x <= 4; x++) for (let y = -4; y <= 4; y++) {
        if (x*x+y*y > 16) continue;
        const point = earth.position.clone().addScaledVector(right, x * 0.19).addScaledVector(up, y * 0.19);
        const direction = point.sub(view.camera.position).normalize();
        const ray = new THREE.Raycaster(view.camera.position, direction);
        if (ray.intersectObject(moon).length) blocked++;
        total++;
      }
      coverage.push(blocked / total);
      assert.ok(Math.abs(center.x) < 0.93 && Math.abs(center.y) < 0.85, 'Earth must stay framed');
      for (const side of [-1, 1]) {
        const edge = moon.position.clone().addScaledVector(right, side).project(view.camera);
        assert.ok(Math.abs(edge.x) < 0.98, 'Moon must stay inside the frame');
      }
      assert.ok(view.camera.position.distanceTo(moon.position) > 1.1, 'camera must not enter Moon');
    }
    assert.equal(coverage[0], 0, 'Earth is visible before crossing');
    assert.equal(coverage.at(-1), 0, 'Earth is visible after crossing');
    assert.ok(coverage.includes(1), 'Moon fully hides Earth');
    assert.ok(coverage.some(k => k > 0 && k < 1), 'edge produces partial occlusion, not a visibility toggle');
  }
  let previous = null;
  for (let t = 0; t <= 82; t += 0.1) {
    view.update(t, 0.5625);
    assert.ok(sun.position.equals(originalSunPosition), 'sunlight direction must not track the camera');
    const observer = view.camera.position.clone().sub(moon.position).normalize();
    moonPhases.push((1 + observer.dot(sunlight)) / 2);
    assert.ok(view.camera.position.distanceTo(moon.position) > 1.05, 'full journey never penetrates the Moon');
    assert.ok(view.camera.position.distanceTo(earth.position) > 0.95, 'departure never penetrates the Earth');
    if (previous) {
      assert.ok(previous.position.distanceTo(view.camera.position) < 0.4, 'no position jump at a shot boundary');
      assert.ok(previous.quaternion.angleTo(view.camera.quaternion) < 0.1, 'no sudden turn at a shot boundary');
    }
    previous = { position: view.camera.position.clone(), quaternion: view.camera.quaternion.clone() };
  }
  view.update(78, 0.5625);
  assert.ok(Math.max(...moonPhases) - Math.min(...moonPhases) > 0.2,
    'orbiting changes the visible lit fraction without rotating the Sun');
  const finalPhase = (1 + view.camera.position.clone().sub(moon.position).normalize().dot(sunlight)) / 2;
  assert.ok(finalPhase > 0.3 && finalPhase < 0.8, 'final Moon view retains both a lit region and a night region');
  view.camera.updateMatrixWorld(true);
  const finalDirection = earth.position.clone().sub(view.camera.position).normalize();
  assert.equal(new THREE.Raycaster(view.camera.position, finalDirection).intersectObject(moon).length, 0, 'Earth remains visible in the final horizon shot');
  assert.ok(earth.position.equals(originalEarthPosition), 'Earth must not follow the camera');
  const scenes = [];
  const captureRenderer = { autoClear: true, gammaOutput: false, gammaFactor: 2,
    setRenderTarget() {}, render(scene, camera) { scenes.push({ scene, camera }); } };
  let lastHeight = Infinity;
  let landingScene;
  for (let t = 80; t <= 104; t += 0.25) {
    view.update(t, 0.5625);
    scenes.length = 0;
    view.render(captureRenderer);
    landingScene = scenes[0].scene;
    landingScene.updateMatrixWorld(true);
    const lander = landingScene.getObjectByName('TRIAL_LANDER');
    assert.ok(lander, 'last act must render the landing stage');
    for (const [mesh, triangles, height] of [[lander, 28530, 2.25], [landingScene.getObjectByName('TRIAL_TRAVELER'), 3692, 1.65]]) {
      assert.equal(mesh.geometry.index.count/3, triangles, 'actual optimized model must replace the proxy');
      mesh.geometry.computeBoundingBox();
      assert.ok(Math.abs(mesh.geometry.boundingBox.min.y) < 1e-5, 'real model feet must be on y=0');
      assert.ok(Math.abs(mesh.geometry.boundingBox.max.y-height) < 1e-5, 'model normalization must retain chosen height');
      assert.equal(mesh.material.map.flipY, false, 'GLB UV uses image top origin');
    }
    assert.ok(lander.position.y <= lastHeight, 'descent must slow to a stable landing without bouncing');
    assert.ok(lander.position.y >= 0, 'landing feet must never penetrate the surface');
    lastHeight = lander.position.y;
    if (t >= 89) assert.equal(lander.position.y, 0, 'foot pads stay in contact after landing');
    const flame = landingScene.getObjectByName('TRIAL_LANDER_FLAME');
    if (t >= 89.5) assert.equal(flame.visible, false, 'engine switches off after touchdown');
    const shadow = landingScene.getObjectByName('TRIAL_LANDER_SHADOW');
    assert.ok(Math.abs(shadow.matrix.determinant()) > 0, 'shadow projection must avoid singular normal-matrix warnings');
    const point = new THREE.Vector3(0, 1, 0).applyMatrix4(shadow.matrix);
    assert.ok(point.y > 0 && point.y < 0.02, 'projected shadow stays on the landing plane');
    assert.ok(point.x > lander.position.x, 'shadow falls away from the fixed Sun');
    const camera = scenes[0].camera;
    camera.updateMatrixWorld(true);
    const localEarth = landingScene.getObjectByName('TRIAL_LANDING_EARTH');
    const traveler = landingScene.getObjectByName('TRIAL_TRAVELER');
    if (t >= 101) {
      for (const object of [lander, traveler, localEarth]) {
        const screen = object.position.clone().project(camera);
        assert.ok(Math.abs(screen.x) < 0.95 && Math.abs(screen.y) < 0.95, `final wide shot must frame ${object.name}: ${screen.toArray()}`);
      }
    }
  }
  assert.ok(earth.position.equals(originalEarthPosition), 'local landing scale must not move the far-scene Earth');
  let landingGeometryDisposed = 0;
  let landingMaterialDisposed = 0;
  let earthMaterialDisposed = 0;
  landingScene.getObjectByName('TRIAL_LANDER').geometry.addEventListener('dispose', () => landingGeometryDisposed++);
  landingScene.getObjectByName('TRIAL_LANDER').material.addEventListener('dispose', () => landingMaterialDisposed++);
  earth.material.addEventListener('dispose', () => earthMaterialDisposed++);
  const renderer = { autoClear: false, gammaOutput: false, gammaFactor: 2,
    setRenderTarget() {}, render() {
      assert.equal(this.gammaOutput, true);
      assert.equal(this.gammaFactor, 2.2);
      throw new Error('GPU failure');
    } };
  assert.throws(() => view.render(renderer), /GPU failure/);
  assert.equal(renderer.gammaOutput, false, 'original renderer colour state must be restored even on failure');
  assert.equal(renderer.gammaFactor, 2);
  assert.equal(renderer.autoClear, false);
  let disposed = 0;
  earth.material.map.addEventListener('dispose', () => disposed++);
  view.dispose();
  view.dispose();
  assert.equal(disposed, 1, 'trial releases each owned texture once');
  assert.equal(landingGeometryDisposed, 1, 'shared lander/shadow geometry is released once');
  assert.equal(landingMaterialDisposed, 1, 'shared lander/traveler material is released once');
  assert.equal(earthMaterialDisposed, 1, 'shared far/local Earth material is released once');

  const pendingView = createMoonTrialScene(THREE, false);
  const cancelled = assert.rejects(pendingView.ready, /取消/);
  pendingView.dispose();
  images.slice(-5).forEach(image => image.dispatchEvent({ type: 'load' }));
  await cancelled;
  assert.equal(pendingView.scene.getObjectByName('TRIAL_EARTH'), undefined);
}

async function testModelReadCancellation() {
  const THREE = createScopedThreejs({width: 390, height: 844, createImage: () => ({})});
  let request;
  const {loadTrialMesh} = load('moon-trial-scene.js', 'loadTrialMesh', {
    wx: {getFileSystemManager: () => ({readFile(options) { request = options; }})}
  });
  const geometry = new THREE.BufferGeometry();
  const pending = loadTrialMesh(THREE, geometry, 'eva00');
  const cancelled = assert.rejects(pending.ready, /取消/);
  pending.cancel();
  const buffer = fs.readFileSync(path.join(__dirname, '../miniprogram/assets/models/eva00.bin'));
  request.success({data: buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset+buffer.byteLength)});
  await cancelled;
  assert.equal(geometry.attributes.position, undefined, 'late model read must not revive disposed geometry');
  const failure = loadTrialMesh(THREE, geometry, 'lander');
  const failed = assert.rejects(failure.ready, /加载失败/);
  request.fail();
  await failed;
  const invalid = loadTrialMesh(THREE, geometry, 'lander');
  const rejected = assert.rejects(invalid.ready, /格式错误/);
  request.success({data: new ArrayBuffer(12)});
  await rejected;
}

(async () => {
  await testModelReadCancellation();
  testRouteExclusion();
  testRenderingIsolation();
  await testTrialLifecycle();
  await testGeometryAndOwnership();
  console.log('moon trial tests passed: route exclusion, lifecycle, real Three.js occlusion, resource ownership');
})().catch(error => { console.error(error); process.exitCode = 1; });
