
// 禅定模式 - 诗词管理模块
// 职责：诗词的加载、播放、特殊彩蛋文本处理

import { APP_CFG, LOG } from './config.js';
import { loadPoetryPresets, loadPoetryLabelsFromDB, loadSpecialTexts } from './content-loader.js';
import { computeStartNearCenter, computeMove } from './poetry-motion.js';

const ENGLISH_ONLY_TRACK_LABELS = {
  102: 'How Deep Is Your Love',
  103: 'Out of Darkness'
};

export async function preloadPoetryCloud(page) {
  const { map, labels, source } = await loadPoetryPresets(APP_CFG, LOG);
  if (Object.keys(map).length) {
    page.__poetryPresets = { ...(page.__poetryPresets || {}), ...map };
    if (Object.keys(labels).length) { page.__presetLabels = { ...(page.__presetLabels || {}), ...labels }; }
    page.__poetrySource = source || page.__poetrySource || 'unknown';
    try {
      if (!Array.isArray(page.__poetryPresets[3]) || page.__poetryPresets[3].length === 0) {
        console.warn('[poetry] 未发现 preset_3，请检查云函数部署/数据库权限/环境ID');
      }
    } catch(_){}
  }
}

export async function pushPoetryPresetToCloud(page, preset) {
  try {
    const lines = page.__poetryPresets[preset] || [];
    const { result } = await wx.cloud.callFunction({ name: 'poetrySets', data: { type: 'upsert', preset, lines } });
    try { console.log('[poetry upsert]', result); } catch(_){}
  } catch(e){ try { console.warn('[poetry upsert] 失败：', e); } catch(_){} }
}

export async function preloadPresetLabelsCloud(page) {
  if (APP_CFG?.cloud?.enabled === false || !(wx && wx.cloud)) { return; }
  if (!page.__poetryPresets || !Object.keys(page.__poetryPresets).length) {
    await preloadPoetryCloud(page);
  }
  const dbLabels = await loadPoetryLabelsFromDB();
  if (Object.keys(dbLabels).length) {
    page.__presetLabels = { ...(page.__presetLabels || {}), ...dbLabels };
  }
}

export async function preloadSpecialCloud(page) {
  const items = await loadSpecialTexts(APP_CFG, LOG);
  page._specialItems = items;
}

export async function playPoetry(page, preset, startIdx, opts) {
  try {
    if (page?.__zenPoetryPaused) {
      try {
        const now = Date.now();
        // Use page property to debounce warning
        if (!page.__poetryPausedWarnAt || (now - page.__poetryPausedWarnAt) >= 5000) {
          page.__poetryPausedWarnAt = now;
          console.warn('[poetry] paused, skip start');
        }
      } catch(_){ }
      return; 
    }
    const p = Number(preset) || 1;
    
    // Lazy Load
    const map = page?.__poetryPresets;
    const has = Array.isArray(map?.[p]) && map[p].length > 0;
    if (!has) {
      try { await preloadPoetryCloud(page); } catch(_){ }
    }

    const isEn = (page.data?.lang === 'en');
    const presetsMap = page?.__poetryPresets || {};
    let useMap = presetsMap;
    if (isEn || p >= 101) {
      try {
        const sanitized = { ...presetsMap };
        const enKeys = Object.keys(presetsMap).map(k=>Number(k)).filter(n=>n>=101).sort((a,b)=>a-b);
        enKeys.forEach(k => {
          const arr = Array.isArray(presetsMap[k]) ? presetsMap[k] : [];
          sanitized[k] = arr.map(line => ({
            ...line,
            text: String(line?.text || '')
              .replace(/[，,]+/g, '\n')
              .replace(/那/g, '')
          }));
        });
        useMap = sanitized;
      } catch(_){ useMap = presetsMap; }
    }
    page?.__getPoetryMgr?.().start(p, useMap, Number(startIdx || 0), opts || {});
  } catch(_){ }
}

export function stopPoetry(page) {
  try { page?.__getPoetryMgr?.().stop(); } catch(_){ }
}

export function resolvePresetForLang(page, current, isEn) {
  try {
    const preset = Number(current) || (isEn ? 101 : 1);
    const audioTrack = preset >= 101 ? preset - 100 : preset;
    if (audioTrack === 2) return 102;
    if (audioTrack === 3) return 103;
    return isEn ? 101 : 1;
  } catch(_){ return isEn ? 101 : 1; }
}

export function resolveNextPreset(page, current, isEn) {
  try {
    const ids = getPresetIdsForLang(isEn);
    const cur = resolvePresetForLang(page, current, isEn);
    const idx = ids.indexOf(cur);
    return ids[(idx >= 0 ? idx + 1 : 0) % ids.length];
  } catch(_){ return 102; }
}

export function getPresetIdsForLang(isEn) {
  return [isEn ? 101 : 1, 102, 103];
}

export function resolvePresetLabel(labels, preset, isEn) {
  const p = Number(preset) || (isEn ? 101 : 1);
  if (ENGLISH_ONLY_TRACK_LABELS[p]) return ENGLISH_ONLY_TRACK_LABELS[p];
  return labels?.[p] || (isEn ? `Track ${p}` : `曲目 ${p}`);
}

// —— 彩蛋逻辑 ——

export function onEggTap(page, triggerSpecialCallback) {
  try {
    if (!page.data.zenMode) return;
    page.__eggTapCount = (page.__eggTapCount || 0) + 1;
    
    clearTimeout(page.__eggTapTimer);
    page.__eggTapTimer = setTimeout(() => { try { page.__eggTapCount = 0; } catch(_){} }, 2000);
    
    if (page.__eggTapCount >= 8) {
      page.__eggTapCount = 0;
      clearTimeout(page.__eggTapTimer);
      if (typeof triggerSpecialCallback === 'function') triggerSpecialCallback();
    }
  } catch(e){ console.error('[ZenMode] Egg tap error:', e); }
}

export async function triggerSpecial(page, mgr) {
  try {
    if (page.data.specialVisible) return;

    let text = '你好，宇宙';
    if (Array.isArray(page._specialItems) && page._specialItems.length > 0) {
      const idx = Math.floor(Math.random() * page._specialItems.length);
      text = page._specialItems[idx];
    }

    if (!Array.isArray(page._specialItems) || !page._specialItems.length) { await preloadSpecialCloud(page); }
    // const items = Array.isArray(page._specialItems) && page._specialItems.length ? page._specialItems : ['你好，宇宙'];
    
    page.__specialIdx = (page.__specialIdx || 0) + 1;
    
    try {
      const fadeMs = Math.max(200, Number(APP_CFG?.poetry?.special?.fadeOutMs || 2000));
      page.setData({ 'poetryA.fadeMs': fadeMs, 'poetryB.fadeMs': fadeMs, 'poetryA.visible': false, 'poetryB.visible': false });
    } catch(_){}
    
    let resumeIdx = 0;
    try {
      const pmgr = page.__getPoetryMgr();
      resumeIdx = pmgr ? pmgr.getIndex() : 0;
    } catch(e) { }
    
    page.__poetryResumeIdx = resumeIdx + 1;
    
    try { stopPoetry(page); } catch(_){}
    
    const delayMs = Math.max(0, Number(APP_CFG?.poetry?.special?.fadeOutMs || 2000));
    setTimeout(() => { try { showSpecial(page, mgr, text); } catch(_){} }, delayMs);
  } catch(_){ }
}

export async function showSpecial(page, mgr, text) {
  try {
    if (!page?.data?.zenMode) return;
    if (page?.__zenPoetryPaused) return;
    const cfg = (APP_CFG && APP_CFG.poetry && APP_CFG.poetry.special) ? APP_CFG.poetry.special : {};
    const fadeInMs = Number(cfg.fadeInMs || 1000);
    const displayMs = Number(cfg.displayMs || 10000);
    const fadeOutMs = Number(cfg.fadeOutMs || 2000);
    const moveSpeed = Number(cfg.movePxPerSec || 12);
    const margin = Number(APP_CFG?.poetry?.safeMarginPx || 18);
    
    const pmgr = page.__getPoetryMgr();
    if (typeof page.__poetryResumeIdx === 'undefined') {
      page.__poetryResumeIdx = pmgr ? pmgr.getIndex() : 0;
      stopPoetry(page);
    }

    const layoutMgr = page.__getLayoutMgr();
    const vp = layoutMgr ? layoutMgr.getViewport() : { windowWidth: 360, windowHeight: 640 };
    const gl = page.__canvasRect;
    
    const fontSize = Math.min(32, Math.max(20, Math.floor(vp.windowWidth * 0.08)));
    page.setData({ 
      specialText: String(text || '你好，宇宙'),
      specialVisible: false, 
      specialMoveMs: 0,
      specialFontSizePx: fontSize,
      specialScale: 1 
    });
    await new Promise(r => setTimeout(r, 50));
    
    let rect = null;
    try {
      rect = layoutMgr ? await layoutMgr.measure('specialText') : null;
    } catch(e) { }

    if (!rect || !rect.width) { rect = { width: Math.min(vp.windowWidth * 0.8, 300), height: 40 }; }
    
    const itemW = Math.max(1, rect.width);
    const itemH = Math.max(1, rect.height);
    const halfCanvasBottom = (gl && typeof gl.top === 'number' && typeof gl.height === 'number')
      ? (gl.top + gl.height * 0.5)
      : (vp.windowHeight * 0.5);
    const bounds = { minX: margin, minY: margin, maxX: vp.windowWidth - margin, maxY: Math.max(margin, Math.min(vp.windowHeight - margin, halfCanvasBottom)) };
    
    let start = computeStartNearCenter(vp.windowWidth, vp.windowHeight, itemW, itemH, bounds, (typeof cfg.upperCenterYRatio === 'number') ? cfg.upperCenterYRatio : 0.35);
    start.x = Math.max(bounds.minX, Math.min(bounds.maxX - itemW, start.x - itemW * 0.5));
    start.y = Math.max(bounds.minY, Math.min(bounds.maxY - itemH, start.y - itemH * 0.5));
    start.y = Math.min(start.y, bounds.maxY - itemH * 0.5);
    
    const move = computeMove(start, itemW, itemH, moveSpeed, displayMs, bounds);
    
    page.setData({ 
      specialX: start.x, specialY: start.y, 
      specialTx: 0, specialTy: 0, 
      specialMoveMs: 0, 
      specialFadeMs: fadeInMs, 
      specialScale: 1.08, 
      specialVisible: false 
    });
    await new Promise(r => setTimeout(r, 20));
    if (!page.data.zenMode) return;
    
    page.setData({ specialVisible: true });
    await new Promise(r => setTimeout(r, 20));
    
    page.setData({ specialMoveMs: displayMs });
    await new Promise(r => setTimeout(r, 20));
    page.setData({ specialTx: move.tx, specialTy: move.ty });
    
    page.__specialTimer = setTimeout(() => {
      if (!page.data.zenMode) return;
      page.setData({ specialFadeMs: fadeOutMs, specialVisible: false });
      
      page.__specialTimer = setTimeout(async () => {
        if (!page.data.zenMode) return;
        const rIdx = page.__poetryResumeIdx || 0;
        const rPreset = page.__zenPreset || (page.data.lang === 'en' ? 101 : 1);
        
        await playPoetry(page, rPreset, 0);
        
        const pmgr = page.__getPoetryMgr?.();
        const zmgr = page.__getZenMgr?.();
        const audioPos = zmgr ? (zmgr.getCurrentTime?.() || 0) * 1000 : 0;
        
        let aligned = false;
        if (pmgr && typeof pmgr.forceAlignToAudioPosition === 'function') {
           aligned = pmgr.forceAlignToAudioPosition(audioPos);
        }
        
        if (!aligned) {
           playPoetry(page, rPreset, rIdx, { keepBaseTime: true });
        }
        
        page.__poetryResumeIdx = undefined;
      }, fadeOutMs + 100);
      
    }, displayMs);
    
  } catch(err){ 
    try { playPoetry(page, page.__zenPreset || 1, 0); } catch(_){}
  }
}

export function stopSpecial(page) {
  try {
    clearTimeout(page?.__specialTimer);
    page?.setData?.({ specialVisible: false });
  } catch(_){ }
}
