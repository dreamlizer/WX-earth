import { fixTexture } from './asset-manager.js';

export const TRIAL_DURATION_SEC = 104;

// 独立叙事场景：固定地月位置，按音频时间推进旅行镜头。
export function createMoonTrialScene(THREE, isPC) {
  const scene = new THREE.Scene();
  // 延续主画布的透明背景，由页面提供黑底，避免遮住小程序浮层。
  const camera = new THREE.PerspectiveCamera(55, 0.46, 0.1, 250);
  // 少量补光只保留暗面轮廓；地月共用固定世界方向的太阳光，不跟随镜头。
  scene.add(new THREE.AmbientLight(0xffffff, 0.018));
  const sun = new THREE.DirectionalLight(0xfff5e6, 1.35);
  sun.name = 'TRIAL_SUN';
  sun.position.set(-10, 3, 2);
  scene.add(sun);

  const moon = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 48),
    new THREE.MeshLambertMaterial({ color: 0xdddddd }));
  moon.name = 'TRIAL_MOON';
  moon.rotation.y = 0.5;
  const earth = new THREE.Mesh(new THREE.SphereGeometry(0.85, 40, 32),
    new THREE.MeshLambertMaterial({ color: new THREE.Color(1.8, 1.8, 1.8), toneMapped: false }));
  earth.name = 'TRIAL_EARTH';
  earth.position.set(0, 0, -40);
  earth.rotation.y = 1.0;
  moon.visible = earth.visible = false;
  scene.add(moon, earth);

  // 稀疏星空只提供空间参照，不使用原场景的云层、标签或光效。
  let seed = 73;
  const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const positions = [];
  for (let i = 0; i < 650; i++) {
    const y = random() * 2 - 1;
    const a = random() * Math.PI * 2;
    const r = Math.sqrt(1 - y * y);
    positions.push(90 * r * Math.cos(a), 90 * y, 90 * r * Math.sin(a));
  }
  const starsGeometry = new THREE.BufferGeometry();
  starsGeometry.addAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const stars = new THREE.Points(starsGeometry,
    new THREE.PointsMaterial({ color: 0xaabbd3, size: 0.14, depthWrite: false }));
  scene.add(stars);

  // 现有白底伴飞素材在渲染时去白，仅在中远景出现一次。
  const companionMaterial = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { map: { value: null }, opacity: { value: 0 } },
    vertexShader: 'varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
    fragmentShader: 'uniform sampler2D map; uniform float opacity; varying vec2 vUv; void main(){vec4 c=texture2D(map,vUv);float a=(1.0-smoothstep(0.78,0.95,min(c.r,min(c.g,c.b))))*opacity;if(a<0.02)discard;gl_FragColor=vec4(c.rgb,a);}'
  });
  const companion = new THREE.Mesh(new THREE.PlaneGeometry(0.56, 1), companionMaterial);
  companion.name = 'TRIAL_COMPANION';
  companion.visible = false;
  scene.add(companion);
  const textures = [];
  let disposed = false;
  let cancelLoad;
  const landing = createLandingStage(THREE, earth.material, sun);
  const textureReady = new Promise((resolve, reject) => {
    let remaining = 5;
    let settled = false;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (error) reject(error);
      else { moon.visible = earth.visible = true; resolve(); }
    };
    const timeout = setTimeout(() => finish(new Error('试航贴图加载超时')), 8000);
    cancelLoad = () => finish(new Error('试航已取消'));
    const loader = new THREE.TextureLoader();
    for (const [mesh, src] of [[moon, '/assets/textures/trial-moon.jpg'], [earth, '/assets/textures/trial-earth.jpg'], [companion, '/assets/textures/trial-companion.png'], [landing.lander, '/assets/models/lander.png'], [landing.person, '/assets/models/eva00.png']]) {
      const texture = loader.load(src, (loaded) => {
        if (disposed || settled) return;
        loaded.encoding = THREE.sRGBEncoding;
        if (mesh === moon || mesh === earth) fixTexture(loaded, isPC);
        if (mesh === landing.lander || mesh === landing.person) loaded.flipY = false;
        loaded.minFilter = THREE.LinearFilter;
        loaded.generateMipmaps = false;
        mesh.material.needsUpdate = true;
        if (--remaining === 0) finish();
      }, undefined, () => finish(new Error('试航贴图加载失败')));
      textures.push(texture);
      if (mesh === companion) companionMaterial.uniforms.map.value = texture;
      else mesh.material.map = texture;
    }
  });

  // 着陆采用独立的局部尺度，沿用地球材质和太阳方向；远景地月关系不被搬动。
  const ready = Promise.all([textureReady, landing.ready]);
  const fadeScene = new THREE.Scene();
  const fadeCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const fade = new THREE.Mesh(new THREE.PlaneGeometry(2, 2),
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, depthTest: false, depthWrite: false }));
  fadeScene.add(fade);
  let landingActive = false;
  let fadeOpacity = 0;

  const towardMoon = new THREE.Vector3();
  const towardEarth = new THREE.Vector3();
  const target = new THREE.Vector3();
  const lookCamera = new THREE.PerspectiveCamera();
  const turnStart = new THREE.Quaternion();
  const turnEnd = new THREE.Quaternion();
  const smooth = (t, a, b) => { const p = Math.max(0, Math.min(1, (t-a)/(b-a))); return p*p*(3-2*p); };
  const move = (a, b, p) => camera.position.set(a[0]+(b[0]-a[0])*p, a[1]+(b[1]-a[1])*p, a[2]+(b[2]-a[2])*p);
  const orbit = (angle, radius, y) => camera.position.set(radius*Math.sin(angle), y, radius*Math.cos(angle));
  const update = (seconds, aspect) => {
    if (disposed) return;
    const t = Math.max(0, Math.min(TRIAL_DURATION_SEC, seconds));
    const ratio = Math.max(0.2, aspect);
    const fov = 2 * Math.atan(Math.tan(25 * Math.PI / 180) / Math.min(ratio, 0.75)) * 180 / Math.PI;
    landingActive = t >= 80;
    fadeOpacity = t >= 79 && t < 81 ? 1 - Math.abs(t - 80) : 0;
    if (landingActive) {
      landing.update(t - 80, ratio, fov);
      return;
    }
    if (camera.aspect !== ratio || camera.fov !== fov) {
      camera.aspect = ratio;
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }
    if (t < 12) {
      move([0, 0.3, -36], [-5, 1, -26], smooth(t, 0, 12));
      camera.lookAt(earth.position);
    } else if (t < 22) {
      move([-5, 1, -26], [-6, 1, -13], smooth(t, 12, 22));
      lookCamera.position.copy(camera.position);
      lookCamera.lookAt(earth.position); turnStart.copy(lookCamera.quaternion);
      lookCamera.lookAt(moon.position); turnEnd.copy(lookCamera.quaternion);
      camera.quaternion.copy(turnStart).slerp(turnEnd, smooth(t, 12, 22));
    } else if (t < 36) {
      move([-6, 1, -13], [-3.39411255, 0.2, -3.39411255], smooth(t, 22, 36));
      camera.lookAt(moon.position);
    } else if (t < 49) {
      orbit(-Math.PI*0.75 + (Math.PI*0.75-0.52)*smooth(t, 36, 49), 4.8, 0.2*(1-smooth(t, 36, 49)));
    } else if (t < 65) {
      // 遮挡段采用平滑轨迹，完整遮挡停留约四秒，两端与前后镜头平滑衔接。
      orbit(-0.52 + 1.04*smooth(t, 49, 65), 4.8, 0);
    } else {
      const p = smooth(t, 65, 77);
      const a = p*Math.PI/2;
      camera.position.set(4.8*Math.sin(0.52)*Math.cos(a), 1.18*Math.sin(a), 4.8*Math.cos(0.52)*(1-p)+0.9*p);
    }
    if (t >= 36) {
      towardMoon.copy(moon.position).sub(camera.position).normalize();
      towardEarth.copy(earth.position).sub(camera.position).normalize();
      const reveal = smooth(t, 40, 49)*0.5;
      target.copy(towardMoon).multiplyScalar(1-reveal).addScaledVector(towardEarth, reveal).normalize();
      if (t >= 65) {
        towardEarth.set(0, -6, -40).sub(camera.position).normalize();
        target.lerp(towardEarth, smooth(t, 65, 77)).normalize();
      }
      camera.lookAt(target.add(camera.position));
    }
    const companionAlpha = smooth(t, 17, 20)*(1-smooth(t, 29, 33));
    companion.visible = companionAlpha > 0 && !disposed;
    companionMaterial.uniforms.opacity.value = companionAlpha;
    if (companion.visible) {
      const p = smooth(t, 17, 33);
      // 角色保持在相机前侧，短暂同行后向月球方向退远。
      const distance = 3 + 5*smooth(t, 26, 33);
      const halfH = distance*Math.tan(camera.fov*Math.PI/360);
      companion.position.set((0.65-0.45*p)*halfH*ratio, -0.27*halfH+Math.sin(t*0.6)*0.015, -distance)
        .applyQuaternion(camera.quaternion).add(camera.position);
      companion.quaternion.copy(camera.quaternion);
      companion.scale.setScalar(halfH*0.3*(1-0.7*smooth(t, 26, 33)));
    }
  };
  update(0, 0.46);

  return {
    scene, camera, ready, update,
    render(renderer) {
      const autoClear = renderer.autoClear;
      const gammaOutput = renderer.gammaOutput;
      const gammaFactor = renderer.gammaFactor;
      try {
        renderer.setRenderTarget(null);
        renderer.autoClear = true;
        // 此小程序适配包的实际渲染器仍使用 gammaOutput，而非 outputEncoding。
        renderer.gammaOutput = true;
        renderer.gammaFactor = 2.2;
        renderer.render(landingActive ? landing.scene : scene, landingActive ? landing.camera : camera);
        if (fadeOpacity > 0) {
          fade.material.opacity = fadeOpacity;
          renderer.autoClear = false;
          renderer.render(fadeScene, fadeCamera);
        }
      } finally {
        renderer.autoClear = autoClear;
        renderer.gammaOutput = gammaOutput;
        renderer.gammaFactor = gammaFactor;
      }
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      cancelLoad();
      landing.dispose();
      fade.geometry.dispose();
      fade.material.dispose();
      // 全部是本场景自己加载/创建的资源，不借用原地球的 Texture 或 Material。
      textures.forEach(texture => texture.dispose());
      for (const mesh of [moon, earth, stars, companion]) {
        mesh.geometry.dispose();
        mesh.material.dispose();
        scene.remove(mesh);
      }
    }
  };
}

// 正式静态模型使用离线烘焙的单网格；低面代理仅用于地面投影。
function createLandingStage(THREE, earthMaterial, sourceSun) {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 0.46, 0.1, 500);
  scene.add(new THREE.AmbientLight(0xffffff, 0.018));
  const sun = new THREE.DirectionalLight(sourceSun.color, sourceSun.intensity);
  sun.position.copy(sourceSun.position);
  scene.add(sun);
  const geometry = new THREE.Geometry();
  const personGeometry = new THREE.Geometry();
  const addPart = (target, shape, color, position, quaternion) => {
    shape.faces.forEach(face => face.color.setHex(color));
    const matrix = new THREE.Matrix4().compose(new THREE.Vector3(...position),
      quaternion || new THREE.Quaternion(), new THREE.Vector3(1, 1, 1));
    target.merge(shape, matrix);
    shape.dispose();
  };
  const rod = (target, a, b, radius, color) => {
    const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b);
    const direction = end.clone().sub(start);
    const rotation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());
    addPart(target, new THREE.CylinderGeometry(radius, radius, direction.length(), 6), color,
      start.add(end).multiplyScalar(0.5).toArray(), rotation);
  };
  addPart(geometry, new THREE.CylinderGeometry(0.5, 0.6, 0.65, 6), 0xc8ced7, [0, 1.05, 0]);
  addPart(geometry, new THREE.ConeGeometry(0.5, 0.45, 6), 0xe4d3a1, [0, 1.6, 0]);
  addPart(geometry, new THREE.BoxGeometry(0.42, 0.22, 0.05), 0x274b66, [0, 1.13, 0.53]);
  addPart(geometry, new THREE.CylinderGeometry(0.14, 0.23, 0.2, 8), 0x535b65, [0, 0.63, 0]);
  for (const x of [-1, 1]) for (const z of [-1, 1]) {
    rod(geometry, [x*0.35, 0.95, z*0.35], [x*0.8, 0.1, z*0.8], 0.055, 0xb9bec6);
    addPart(geometry, new THREE.CylinderGeometry(0.19, 0.19, 0.08, 8), 0xc8b78d, [x*0.8, 0.04, z*0.8]);
  }
  const lander = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshLambertMaterial({ vertexColors: THREE.VertexColors }));
  lander.name = 'TRIAL_LANDER';
  scene.add(lander);

  // 一位等候的占位旅伴，先保留站姿，不假装已实现出舱和行走。
  addPart(personGeometry, new THREE.BoxGeometry(0.32, 0.42, 0.23), 0xd1b45d, [0, 0.88, 0]);
  addPart(personGeometry, new THREE.BoxGeometry(0.23, 0.3, 0.13), 0xbec7d0, [0, 0.88, 0.18]);
  addPart(personGeometry, new THREE.SphereGeometry(0.19, 10, 8), 0xe0d7bc, [0, 1.27, 0]);
  addPart(personGeometry, new THREE.BoxGeometry(0.25, 0.12, 0.045), 0x172936, [0, 1.29, -0.17]);
  for (const side of [-1, 1]) {
    rod(personGeometry, [side*0.09, 0.7, 0], [side*0.14, 0.1, 0], 0.075, 0xc8cbd0);
    rod(personGeometry, [side*0.22, 1.02, 0], [side*0.3, 0.62, -0.04], 0.055, 0xd1b45d);
    addPart(personGeometry, new THREE.BoxGeometry(0.17, 0.1, 0.26), 0x7b838e, [side*0.14, 0.05, -0.04]);
  }
  const person = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshLambertMaterial({ vertexColors: THREE.VertexColors }));
  person.name = 'TRIAL_TRAVELER';
  person.position.set(1.7, 0, -0.7);
  scene.add(person);
  // 面向远方地球，略偏侧身，保留肩膀与头部轮廓。
  person.rotation.y = Math.PI + 0.35;
  const loads = [loadTrialMesh(THREE, lander.geometry, 'lander'), loadTrialMesh(THREE, person.geometry, 'eva00')];
  const ready = Promise.all(loads.map(load => load.ready));

  const groundGeometry = new THREE.PlaneGeometry(240, 240, 40, 40);
  groundGeometry.rotateX(-Math.PI/2);
  groundGeometry.vertices.forEach(v => {
    const edge = Math.min(1, Math.max(0, (Math.hypot(v.x, v.z) - 14) / 18));
    v.y = edge * (0.35*Math.sin(v.x*0.23)*Math.cos(v.z*0.19) + 0.18*Math.sin(v.z*0.37));
  });
  groundGeometry.computeFaceNormals();
  const groundMaterial = new THREE.MeshLambertMaterial({ color: 0x94969d, flatShading: true });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.name = 'TRIAL_LANDING_GROUND';
  scene.add(ground);
  const earth = new THREE.Mesh(new THREE.SphereGeometry(6, 32, 24), earthMaterial);
  earth.name = 'TRIAL_LANDING_EARTH';
  earth.position.set(0, 16, -300);
  earth.rotation.y = 1;
  scene.add(earth);

  // 将占位轮廓沿太阳光投到平坦接地区，避免开启阴影贴图和额外渲染目标。
  const shadowMaterial = new THREE.MeshBasicMaterial({ color: 0x12151a, depthWrite: false, side: THREE.DoubleSide });
  const projection = new THREE.Matrix4().set(
    1, -sun.position.x/sun.position.y, 0, 0,
    0, 0.00001, 0, 0.012,
    0, -sun.position.z/sun.position.y, 1, 0,
    0, 0, 0, 1);
  const shadows = [lander, person].map((body, i) => {
    const shadow = new THREE.Mesh(i === 0 ? geometry : personGeometry, shadowMaterial);
    shadow.name = body.name + '_SHADOW';
    shadow.matrixAutoUpdate = false;
    shadow.frustumCulled = false;
    scene.add(shadow);
    return shadow;
  });
  const flameMaterial = new THREE.MeshBasicMaterial({ color: 0xf5c378, transparent: true, depthWrite: false });
  const flame = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.65, 10), flameMaterial);
  flame.name = 'TRIAL_LANDER_FLAME';
  flame.rotation.z = Math.PI;
  scene.add(flame);
  const smooth = (t, start, end) => {
    const p = Math.max(0, Math.min(1, (t-start)/(end-start)));
    return p*p*(3-2*p);
  };
  return {
    scene, camera, lander, person, ready,
    update(t, aspect, fov) {
      camera.aspect = aspect;
      camera.fov = fov;
      camera.updateProjectionMatrix();
      const descent = smooth(t, 0, 9);
      lander.position.set(-1.2, 4.2*(1-descent), 0);
      // 脚垫最低点为局部 y=0，落地后保持精确接触，避免弹进地面。
      flame.visible = t < 9.5;
      const power = 1-smooth(t, 8.5, 9.5);
      flame.position.set(lander.position.x, lander.position.y+0.48-0.325*power, 0);
      flame.scale.set(1, Math.max(0.001, power), 1);
      flameMaterial.opacity = power*0.75;
      [lander, person].forEach((body, i) => {
        body.updateMatrix();
        shadows[i].matrix.multiplyMatrices(projection, body.matrix);
        shadows[i].matrixWorldNeedsUpdate = true;
      });
      const reveal = smooth(t, 12, 21);
      camera.position.set(5-4.4*reveal, 3.4-1.6*reveal, 7.5);
      camera.lookAt(new THREE.Vector3(0, 1+0.8*reveal, -1-19*reveal));
    },
    dispose() {
      geometry.dispose();
      personGeometry.dispose();
      loads.forEach(load => load.cancel());
      lander.geometry.dispose();
      person.geometry.dispose();
      lander.material.dispose();
      person.material.dispose();
      groundGeometry.dispose();
      groundMaterial.dispose();
      earth.geometry.dispose();
      shadowMaterial.dispose();
      flame.geometry.dispose();
      flameMaterial.dispose();
      // 地球材质与贴图由远景场景持有并统一释放。
    }
  };
}

// MV01: counts + positions(float32), normals(int8), UV(uint16), colors(uint8), indices(uint16).
// 只读项目离线生成的数据，不在手机端引入 GLB/Draco 解码器。
function loadTrialMesh(THREE, geometry, name) {
  let cancel;
  const ready = new Promise((resolve, reject) => {
    let settled = false;
    const finish = error => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error); else resolve();
    };
    const timer = setTimeout(() => finish(new Error('试航模型加载超时')), 8000);
    cancel = () => finish(new Error('试航已取消'));
    wx.getFileSystemManager().readFile({
      filePath: '/assets/models/' + name + '.bin',
      success({ data }) {
        if (settled) return;
        try {
          const header = new DataView(data);
          if (header.getUint32(0, true) !== 0x3130564d) throw new Error('试航模型格式错误');
          const vertices = header.getUint32(4, true), count = header.getUint32(8, true);
          let offset = 12;
          geometry.addAttribute('position', new THREE.BufferAttribute(new Float32Array(data, offset, vertices*3), 3));
          offset += vertices*12;
          geometry.addAttribute('normal', new THREE.BufferAttribute(new Int8Array(data, offset, vertices*3), 3, true));
          offset = (offset + vertices*3 + 3) & ~3;
          geometry.addAttribute('uv', new THREE.BufferAttribute(new Uint16Array(data, offset, vertices*2), 2, true));
          offset += vertices*4;
          geometry.addAttribute('color', new THREE.BufferAttribute(new Uint8Array(data, offset, vertices*3), 3, true));
          offset = (offset + vertices*3 + 3) & ~3;
          geometry.setIndex(new THREE.BufferAttribute(new Uint16Array(data, offset, count), 1));
          geometry.computeBoundingSphere();
          finish();
        } catch (error) { finish(error); }
      },
      fail() { finish(new Error('试航模型加载失败')); }
    });
  });
  return { ready, cancel: () => cancel() };
}
