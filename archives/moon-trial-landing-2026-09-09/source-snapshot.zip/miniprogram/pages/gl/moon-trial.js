import { createMoonTrialScene, TRIAL_DURATION_SEC } from './moon-trial-scene.js';
import { APP_CFG } from './config.js';
import { playPoetry } from './zen-poetry.js';

export class MoonTrial {
  constructor(THREE, page, Audio = MoonTrialAudio) {
    this.Audio = Audio;
    this.THREE = THREE;
    this.page = page;
    this.view = null;
    this.active = false;
    this.playing = false;
    this.token = 0;
    this.disposed = false;
    this.audio = null;
    this.zenSnapshot = null;
    this.lastTime = 0;
    this.lastAdvanceAt = 0;
  }

  isActive() { return this.active; }

  async enter() {
    if (this.disposed || this.active || !this.page?.data?.zenMode) return;
    const token = ++this.token;
    this.active = true;
    this.page.__getZenModeMgr?.()?.closeList?.();
    const zen = this.page.__getZenMgr?.();
    const poetry = this.page.__getPoetryMgr?.();
    this.zenSnapshot = { zen, index: poetry?.getIndex?.() || 0, preset: this.page.__zenPreset || 1 };
    this.page.__zenPoetryPaused = true;
    zen?.suspend?.();
    poetry?.stop?.();
    this.page.setData({ moonTrialActive: true, moonTrialLoading: true });
    try {
      this.view = createMoonTrialScene(this.THREE, !!this.page.data.isPC);
      this.audio = new this.Audio((error) => {
        if (token !== this.token) return;
        this.exit();
        this.page?.showMoonToast?.(error.message);
      }, () => { if (token === this.token) this.exit(); });
      await this.view.ready;
      if (token !== this.token || this.disposed) return;
      await this.audio.start();
      if (token !== this.token || this.disposed) return;
      this.playing = true;
      this.lastTime = 0;
      this.lastAdvanceAt = 0;
      this.page.setData({ moonTrialLoading: false });
    } catch (error) {
      if (token !== this.token || this.disposed) return;
      console.warn('[MoonTrial]', error.message);
      this.exit();
      this.page?.showMoonToast?.(error.message || '试航暂未准备好，请重试');
    }
  }

  render(renderer, aspect, now) {
    if (!this.active || !this.view) return false;
    const elapsed = this.playing ? this.audio.getTime() : 0;
    if (this.playing) {
      if (!this.lastAdvanceAt || elapsed > this.lastTime) this.lastAdvanceAt = now;
      this.lastTime = elapsed;
      if (now - this.lastAdvanceAt > 15000) {
        this.exit();
        this.page?.showMoonToast?.('音乐缓冲过久，已返回禅定');
        return false;
      }
      this.audio.fadeOut((elapsed - (TRIAL_DURATION_SEC - 3)) / 3);
    }
    if (elapsed >= TRIAL_DURATION_SEC) {
      this.exit();
      return false;
    }
    try {
      this.view.update(elapsed, aspect);
      this.view.render(renderer);
      return true;
    } catch (error) {
      console.warn('[MoonTrial] Render failed:', error.message);
      this.exit();
      this.page?.showMoonToast?.('试航已返回');
      return false;
    }
  }

  exit(updatePage = true, resume = true) {
    if (!this.active) return;
    ++this.token;
    this.active = false;
    this.playing = false;
    this.view?.dispose();
    this.view = null;
    this.audio?.dispose();
    this.audio = null;
    if (updatePage) this.page?.setData?.({ moonTrialActive: false, moonTrialLoading: false });
    if (updatePage && resume) this.resumeZen();
  }

  resumeZen() {
    const saved = this.zenSnapshot;
    this.zenSnapshot = null;
    if (!saved || this.disposed || !this.page?.data?.zenMode) return;
    this.page.__zenPoetryPaused = false;
    playPoetry(this.page, saved.preset, saved.index, { keepBaseTime: true });
    saved.zen?.resume?.();
  }

  dispose() {
    this.disposed = true;
    this.exit(false);
    this.zenSnapshot = null;
    this.page = null;
    this.THREE = null;
  }
}


const AUDIO_FILE = 'cloud://cloud1-1g6316vt2769d82c.636c-cloud1-1g6316vt2769d82c-1380715696/assets/Moon/Zen-moon.mp3';
let cachedPath = '';

export class MoonTrialAudio {
  constructor(onFailure, onEnded) {
    this.ctx = null;
    this.disposed = false;
    this.onFailure = onFailure;
    this.onEnded = onEnded;
    this.cancel = null;
    this.volume = Math.max(0, Math.min(1, Number(APP_CFG?.audio?.zenVolume ?? 1) * Number(APP_CFG?.audio?.moonVolumeMul ?? 1)));
  }

  start() {
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        error ? reject(error) : resolve();
      };
      const timer = setTimeout(() => finish(new Error('登月音乐加载超时')), 30000);
      this.cancel = () => finish(new Error('试航已取消'));
      const play = (src) => {
        if (this.disposed || settled) return;
        try {
          const ctx = wx.createInnerAudioContext();
          this.ctx = ctx;
          ctx.autoplay = false;
          ctx.loop = false;
          ctx.volume = this.volume;
          ctx.onPlay(() => { if (!this.disposed) finish(); });
          ctx.onError(() => {
            if (this.disposed) return;
            const error = new Error('登月音乐播放失败');
            if (!settled) finish(error); else this.onFailure(error);
          });
          ctx.onEnded(() => { if (!this.disposed) this.onEnded(); });
          ctx.src = src;
          ctx.play();
        } catch (error) { finish(error); }
      };
      try {
        if (cachedPath) {
          try { wx.getFileSystemManager().accessSync(cachedPath); } catch (_) { cachedPath = ''; }
        }
        if (cachedPath) { play(cachedPath); return; }
        wx.cloud.downloadFile({
          fileID: AUDIO_FILE,
          success: (result) => {
            if (this.disposed || settled) return;
            if (!result.tempFilePath) { finish(new Error('登月音乐下载失败')); return; }
            cachedPath = result.tempFilePath;
            play(cachedPath);
          },
          fail: () => finish(new Error('登月音乐下载失败'))
        });
      } catch (error) { finish(error); }
    });
  }

  getTime() { return Math.max(0, Number(this.ctx?.currentTime || 0)); }
  fadeOut(progress) { if (this.ctx) this.ctx.volume = this.volume * (1 - Math.max(0, Math.min(1, progress))); }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.cancel?.();
    try { this.ctx?.stop(); } catch (_) {}
    try { this.ctx?.destroy(); } catch (_) {}
    this.ctx = null;
  }
}
