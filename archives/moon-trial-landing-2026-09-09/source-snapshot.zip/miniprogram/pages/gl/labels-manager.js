// 负责：语言切换、标签数量与城市级别、标签重建与城市淡点初始化
import { getCountries, getRenderContext } from './main.js';
import { initLabels, setLabelsBudget, clearForcedLabel, forceHideAllMeshes } from './labels.js';
import { initCityMarkers } from './city-markers.js';
import { ENABLE_CITY_LABELS, INTERACTION_DEBUG_LOG, LABELS_DEBUG_LOG } from './label-constants.js';
import { cities } from '../../assets/data/cities_data.js';

export class LabelsManager {
  constructor(page){ this.page = page; }

  onSetLabelQty(e){
    const v = e?.currentTarget?.dataset?.val || e?.detail?.value || 'default';
    
    let n = 22; 
    let tier = 'default';

    if (v === 'none') {
      n = 0;
      tier = 'none';
    } else if (v === 'few') {
      n = 10;
      tier = 'key';
    } else if (v === 'many') {
      n = 60;
      tier = 'more';
    } else {
      // default
      n = 22;
      tier = 'default';
    }

    this.page.setData({ labelQty: v, cityTier: tier });
    setLabelsBudget(n);
    this.rebuildLabelsByLang(this.page.data.lang);
  }

  forceHideAll() {
    setLabelsBudget(0);
    clearForcedLabel();
    forceHideAllMeshes();
  }
  
  restore(qty) {
    const v = qty || this.page.data.labelQty || 'default';
    let n = 22;
    if (v === 'none') n = 0; else if (v === 'few') n = 10; else if (v === 'many') n = 60; else n = 22;
    setLabelsBudget(n);
  }

  onToggleLang(){
    try {
      if (this.page?.data?.settingsOpen) { this.page.__getPanelMgr?.().closeSettings?.(); }
      // 调整：切换语言时不关闭国家面板，而是就地刷新
      try { this.page.updateTopOffsets?.(); } catch(_){ }
    } catch(_){ }
    const next = this.page.data.lang === 'zh' ? 'en' : 'zh';
    const labels = this.page.data.uiLabels[next] || this.page.data.uiLabels.zh;
    // 切换语言：更新标签与诗句字号（英文小一号）
    const basePx = Number(this.page.data.poetryFontSizeBasePx || this.page.data.poetryFontSizePx || 16);
    const enPx = Math.max(10, basePx - 2);
    const zhPx = basePx;
    this.page.setData({ lang: next, labels, poetryFontSizePx: next === 'en' ? enPx : zhPx });
    try { this.page.updateCountryTitleSuffix && this.page.updateCountryTitleSuffix(); } catch(_){}
    this.rebuildLabelsByLang(next);

    // 尝试刷新当前打开的国家面板（如果有）
    try {
      if (this.page.data.countryPanelOpen && this.page.data.countryInfo?.code) {
        const code = String(this.page.data.countryInfo.code).toUpperCase();
        const features = this.page._features || [];
        const feature = features.find(f => {
           const p = f.props || {};
           const c = p.ISO_A3 || p.ISO_A2 || p.ISO || p.CC || p.ISO2;
           return c && String(c).toUpperCase() === code;
        });
        // 即使没有 feature (rare)，也可以传 null 让其关闭？不，最好保持原样。
        // 但这里我们只在有 feature 时刷新。
        if (feature) {
          // 强制刷新
          this.page.__getCountryMgr().onCountryPicked(feature, true);
        }
      }
    } catch(_){ }

    // 若处于禅定模式：切换对应语言的诗句预设组（中文1，英文4）
    try {
      if (this.page?.data?.zenMode) {
        let preset = (next === 'en') ? 101 : 1;
        if (next === 'en') {
          try {
            const map = this.page?.__poetryPresets || {};
            const keys = Object.keys(map).map(k=>Number(k)).filter(n=>n>=101).sort((a,b)=>a-b);
            if (keys.length) preset = keys[0];
          } catch(_){ }
        }
        this.page.__zenPreset = preset;
        // 视觉平滑：淡出当前，再在1秒后切入新预设（与切换逻辑一致）
        try { this.page?._stopZenAudio?.(2000); } catch(_){ }
        try { this.page?.setData?.({ 'poetryA.fadeMs': 2000, 'poetryB.fadeMs': 2000, 'poetryA.visible': false, 'poetryB.visible': false }); } catch(_){ }
        setTimeout(() => {
          // 英文仍播放 1–3 三首：将 4–6 映射到 1–3
          const audioPreset = (next === 'en') ? Math.max(1, preset - 100) : preset;
        try { this.page?._startZenAudio?.(audioPreset); } catch(_){ }
        try { this.page?.__getPoetryMgr?.().resetImmediate?.(); } catch(_){ }
        try { this.page?.__startPoetryViaMgr?.(preset, 0); } catch(_){ }
        }, 1000);
      }
    } catch(_){}
  }

  initOnce(lang){
    const doInit = () => {
      try {
        const ctx = getRenderContext();
        if (ctx && ctx.globeGroup && ctx.camera) {
          this.rebuildLabelsByLang(lang || (this.page?.data?.lang || 'zh'));
          return;
        }
      } catch(_){ }
      setTimeout(doInit, 100);
    };
    doInit();
  }

  rebuildLabelsByLang(lang, featuresArg){
    try {
      if (Array.isArray(featuresArg) && featuresArg.length) { this.page._features = featuresArg; }
      const features = (Array.isArray(featuresArg) && featuresArg.length)
        ? featuresArg
        : (Array.isArray(this.page._features) && this.page._features.length ? this.page._features : getCountries());
      if (Array.isArray(features) && features.length) {
        if (!this.page._countryDict) {
          try { this.page._countryDict = require('./country_data.js').default || require('./country_data.js'); } catch(_) { this.page._countryDict = null; }
        }
        const dict = this.page._countryDict || {};
        const POS_OVERRIDES = {
          US: { lon: -98.8433, lat: 38.2847 },
          USA: { lon: -98.8433, lat: 38.2847 },
          RU: { lon: 105.0, lat: 61.0 },
          RUS: { lon: 105.0, lat: 61.0 },
          FR: { lon: 2.8, lat: 49.0 },
          FRA: { lon: 2.8, lat: 49.0 },
        };
        // 过滤：移除台湾的国家标签（TWN/TW）
        const filteredFeatures = features.filter(f => {
          const p = f?.props || {};
          const code = String(p.ISO_A3 || p.ISO_A2 || p.ISO || '').toUpperCase();
          return code !== 'TWN' && code !== 'TW';
        });
        const baseLabels = filteredFeatures.map((f, idx) => {
          const p = f.props || {};
          const code = String(p.ISO_A3 || p.ISO_A2 || p.ISO || '').toUpperCase();
          const fromDict = dict && code ? (dict[code] || dict[code.padStart(3,'0')]) : null;
          const nameEn = p.NAME_EN || p.ADMIN_EN || p.NAME_LONG_EN || (fromDict ? (fromDict.NAME_EN || fromDict.CAPITAL_EN) : null) || p.NAME || p.ADMIN || `#${idx}`;
          const nameZh = p.NAME_ZH || p.ADMIN_ZH || (fromDict ? (fromDict.NAME_ZH || fromDict.CAPITAL_ZH) : '');
          const name = (lang === 'zh') ? (nameZh || nameEn) : (nameEn || nameZh || `#${idx}`);
          const [minLon, minLat, maxLon, maxLat] = f.bbox || [-10,-10,10,10];
          let lon = (minLon + maxLon) / 2;
          let lat = (minLat + maxLat) / 2;
          if (POS_OVERRIDES[code]) { lon = POS_OVERRIDES[code].lon; lat = POS_OVERRIDES[code].lat; }
          const id = p.ISO_A3 || p.ISO_A2 || p.ISO || String(idx);
          // 提升中国国家标签的排序分数，确保默认优先显示
          const isChina = (code === 'CHN' || code === 'CN');
          const score = isChina ? 999 : undefined;
          return { id, text: name, isCity: false, lon, lat, area: Math.max(1, Math.log10((p.AREA || 5000))), score };
        });

        let cityLabels = [];
        const cloudCities = Array.isArray(this.page._citiesCloud) && this.page._citiesCloud.length ? this.page._citiesCloud : null;
        const srcCities = cloudCities || (Array.isArray(cities) ? cities : []);
        if (ENABLE_CITY_LABELS && Array.isArray(srcCities) && srcCities.length) {
          const tier = this.page.data.cityTier || 'more';
          let filtered = srcCities;
          if (tier === 'none') {
            filtered = [];
          } else if (tier === 'key') {
            filtered = srcCities.filter(c => Math.round(Number(c.importance || 0)) === 1);
          } else {
            filtered = srcCities.filter(c => Number(c.importance || 0) >= 1);
          }
          // 过滤台湾的城市，仅保留台北
          // 规则：country_code === 'TWN' 且 name_en === 'Taipei' 或中文包含“台北”保留，其他台湾城市移除
          filtered = filtered.filter(c => {
            const cc = String(c.country_code || '').toUpperCase();
            if (cc !== 'TWN') return true;
            const en = String(c.name_en || '');
            const zh = String(c.name_zh || '');
            const isTaipei = (/^taipei$/i.test(en)) || (zh.indexOf('台北') >= 0);
            return isTaipei;
          });
          cityLabels = filtered.map((c, i) => {
            const text = (lang === 'zh') ? (c.name_zh || c.name_en || `City#${i}`) : (c.name_en || c.name_zh || `City#${i}`);
            const id = `CITY_${c.country_code || 'UNK'}_${c.name_en || text}`;
            const score = (typeof c.importance === 'number') ? (1.0 + c.importance) : 1.0;
            const importance = (typeof c.importance === 'number') ? Math.round(c.importance) : 1;
            return { id, text, isCity: true, lon: c.lon, lat: c.lat, score, importance, country: c.country_code || null };
          });
          try { if (INTERACTION_DEBUG_LOG) console.log(`[settings] 城市显示: ${tier}, labels=${cityLabels.length}`); } catch(_){}

          const ctx = getRenderContext();
          if (ctx && ctx.THREE && ctx.globeGroup) {
            initCityMarkers(ctx.THREE, ctx.globeGroup, filtered);
          }
        }
        const total = baseLabels.length + cityLabels.length;
        initLabels(baseLabels.concat(cityLabels));
        try { if (LABELS_DEBUG_LOG) console.info(`[labels rebuild] base=${baseLabels.length}, city=${cityLabels.length}, total=${total}`); } catch(_){}
      } else {
        if (!this.page.__rebuildWarnedOnce) {
          try { if (LABELS_DEBUG_LOG) console.warn('[labels rebuild] features not ready yet; will rebuild after load'); } catch(_){ }
          this.page.__rebuildWarnedOnce = true;
        }
      }
    } catch (e) { console.warn('[labels rebuild] failed:', e); }
  }

  // 国家数据加载完成后统一入口：缓存 features 并依当前语言重建标签
  onCountriesLoaded(features){
    try {
      if (Array.isArray(features) && features.length) {
        this.page._features = features;
      }
    } catch(_) {}
    return this.rebuildLabelsByLang(this.page?.data?.lang || 'zh', features);
  }

  async preloadCitiesCloud(){
    if (!(wx && wx.cloud && typeof wx.cloud.callFunction === 'function')) {
      try { if (INTERACTION_DEBUG_LOG) console.warn('[cities] 云能力不可用，跳过预加载'); } catch(_){}
      this.page._citiesCloud = null;
      return;
    }
    try {
      const { result } = await wx.cloud.callFunction({ name: 'citiesFetch', data: { type: 'list' } });
      const arr = result && Array.isArray(result.data) ? result.data : [];
      if (arr.length) {
        this.page._citiesCloud = arr.map(x => ({
          name_en: x.name_en || '',
          name_zh: x.name_zh || '',
          lat: Number(x.lat),
          lon: Number(x.lon),
          country_code: String(x.country_code || '').toUpperCase(),
          importance: typeof x.importance === 'number' ? x.importance : 1,
        })).filter(c => Number.isFinite(c.lat) && Number.isFinite(c.lon));
        try { if (INTERACTION_DEBUG_LOG) console.log(`[cities] 云端加载 ${this.page._citiesCloud.length} 条`); } catch(_){}
        this.rebuildLabelsByLang(this.page.data.lang);
      }
    } catch (e) {
      try { if (INTERACTION_DEBUG_LOG) console.warn('[cities] 云端读取失败，回退本地：', e); } catch(_){}
      this.page._citiesCloud = null;
    }
  }

  // 开发者工具控制台调用：将本地 cities 数据分批写入云数据库（应急）
  async pushCitiesToCloudLocal(chunkSize = 200){
    try {
      const arr = (Array.isArray(cities) ? cities : []).map(x => ({
        name_en: x.name_en || '',
        name_zh: x.name_zh || '',
        lat: Number(x.lat),
        lon: Number(x.lon),
        country_code: String(x.country_code || '').toUpperCase(),
        importance: typeof x.importance === 'number' ? x.importance : 1,
      })).filter(c => Number.isFinite(c.lat) && Number.isFinite(c.lon));
      let done = 0;
      for (let i = 0; i < arr.length; i += chunkSize) {
        const batch = arr.slice(i, i + chunkSize);
        const { result } = await wx.cloud.callFunction({ name: 'citiesImport', data: { type: 'bulkUpsert', items: batch } });
        done += batch.length;
        try { console.log(`[import] 已写入 ${done}/${arr.length}`, result); } catch(_){}
      }
      try { console.log('[import] 完成'); } catch(_){}
    } catch (e) { console.warn('[import] 失败：', e); }
  }
}
