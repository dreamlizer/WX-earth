export const cities = [
  {
    "name_en": "Beijing",
    "name_zh": "北京",
    "lat": 39.9042,
    "lon": 116.4074,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "beijing",
    "pinyin_initial": "bj"
  },
  {
    "name_en": "Shanghai",
    "name_zh": "上海",
    "lat": 31.2304,
    "lon": 121.4737,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "shanghai",
    "pinyin_initial": "sh"
  },
  {
    "name_en": "Guangzhou",
    "name_zh": "广州",
    "lat": 23.1291,
    "lon": 113.2644,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "guangzhou",
    "pinyin_initial": "gz"
  },
  {
    "name_en": "Shenzhen",
    "name_zh": "深圳",
    "lat": 22.5431,
    "lon": 114.0579,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "shenzhen",
    "pinyin_initial": "sz"
  },
  {
    "name_en": "Chengdu",
    "name_zh": "成都",
    "lat": 30.5728,
    "lon": 104.0668,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "chengdu",
    "pinyin_initial": "cd"
  },
  {
    "name_en": "Chongqing",
    "name_zh": "重庆",
    "lat": 29.563,
    "lon": 106.5516,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "chongqing",
    "pinyin_initial": "cq"
  },
  {
    "name_en": "Wuhan",
    "name_zh": "武汉",
    "lat": 30.6622,
    "lon": 114.3055,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "wuhan",
    "pinyin_initial": "wh"
  },
  {
    "name_en": "Xi'an",
    "name_zh": "西安",
    "lat": 34.3416,
    "lon": 108.9402,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "xian",
    "pinyin_initial": "xa"
  },
  {
    "name_en": "Hangzhou",
    "name_zh": "杭州",
    "lat": 30.2741,
    "lon": 120.1551,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "hangzhou",
    "pinyin_initial": "hz"
  },
  {
    "name_en": "Lhasa",
    "name_zh": "拉萨",
    "lat": 29.6456,
    "lon": 91.1402,
    "country_code": "CHN",
    "importance": 2,
    "pinyin_full": "lasa",
    "pinyin_initial": "ls"
  },
  {
    "name_en": "New York",
    "name_zh": "纽约",
    "lat": 40.7128,
    "lon": -74.006,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "niuyue",
    "pinyin_initial": "ny"
  },
  {
    "name_en": "Chicago",
    "name_zh": "芝加哥",
    "lat": 41.8781,
    "lon": -87.6298,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "zhijiage",
    "pinyin_initial": "zjg"
  },
  {
    "name_en": "Denver",
    "name_zh": "丹佛",
    "lat": 39.7392,
    "lon": -104.9903,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "danfo",
    "pinyin_initial": "df"
  },
  {
    "name_en": "Los Angeles",
    "name_zh": "洛杉矶",
    "lat": 34.0522,
    "lon": -118.2437,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "luoshanji",
    "pinyin_initial": "lsj"
  },
  {
    "name_en": "Anchorage",
    "name_zh": "安克雷奇",
    "lat": 61.2181,
    "lon": -149.9003,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "ankeleiqi",
    "pinyin_initial": "aklq"
  },
  {
    "name_en": "Honolulu",
    "name_zh": "檀香山",
    "lat": 21.3069,
    "lon": -157.8583,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "tanxiangshan",
    "pinyin_initial": "txs"
  },
  {
    "name_en": "Washington D.C.",
    "name_zh": "华盛顿",
    "lat": 38.9072,
    "lon": -77.0369,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "huashengdun",
    "pinyin_initial": "hsd"
  },
  {
    "name_en": "Houston",
    "name_zh": "休斯顿",
    "lat": 29.7604,
    "lon": -95.3698,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "xiusidun",
    "pinyin_initial": "xsd"
  },
  {
    "name_en": "Seattle",
    "name_zh": "西雅图",
    "lat": 47.6062,
    "lon": -122.3321,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "xiyatu",
    "pinyin_initial": "xyt"
  },
  {
    "name_en": "Miami",
    "name_zh": "迈阿密",
    "lat": 25.7617,
    "lon": -80.1918,
    "country_code": "USA",
    "importance": 2,
    "pinyin_full": "maiami",
    "pinyin_initial": "mam"
  },
  {
    "name_en": "Moscow",
    "name_zh": "莫斯科",
    "lat": 55.7558,
    "lon": 37.6173,
    "country_code": "RUS",
    "importance": 2,
    "pinyin_full": "mosike",
    "pinyin_initial": "msk"
  },
  {
    "name_en": "St. Petersburg",
    "name_zh": "圣彼得堡",
    "lat": 59.9343,
    "lon": 30.3351,
    "country_code": "RUS",
    "importance": 2,
    "pinyin_full": "shengbidebao",
    "pinyin_initial": "sbdb"
  },
  {
    "name_en": "Yekaterinburg",
    "name_zh": "叶卡捷琳堡",
    "lat": 56.8389,
    "lon": 60.6057,
    "country_code": "RUS",
    "importance": 2,
    "pinyin_full": "yekajielinbao",
    "pinyin_initial": "ykjlb"
  },
  {
    "name_en": "Novosibirsk",
    "name_zh": "新西伯利亚",
    "lat": 55.0084,
    "lon": 82.9357,
    "country_code": "RUS",
    "importance": 2,
    "pinyin_full": "xinxiboliya",
    "pinyin_initial": "xxbly"
  },
  {
    "name_en": "Vladivostok",
    "name_zh": "符拉迪沃斯托克",
    "lat": 43.1198,
    "lon": 131.8869,
    "country_code": "RUS",
    "importance": 2,
    "pinyin_full": "fuladiwosituoke",
    "pinyin_initial": "fldwstk"
  },
  {
    "name_en": "Ottawa",
    "name_zh": "渥太华",
    "lat": 45.4215,
    "lon": -75.6997,
    "country_code": "CAN",
    "importance": 1,
    "pinyin_full": "wotaihua",
    "pinyin_initial": "wth"
  },
  {
    "name_en": "Toronto",
    "name_zh": "多伦多",
    "lat": 43.651,
    "lon": -79.347,
    "country_code": "CAN",
    "importance": 1,
    "pinyin_full": "duolunduo",
    "pinyin_initial": "dld"
  },
  {
    "name_en": "Montreal",
    "name_zh": "蒙特利尔",
    "lat": 45.5017,
    "lon": -73.5673,
    "country_code": "CAN",
    "importance": 1,
    "pinyin_full": "mengtelier",
    "pinyin_initial": "mtle"
  },
  {
    "name_en": "Winnipeg",
    "name_zh": "温尼伯",
    "lat": 49.8951,
    "lon": -97.1384,
    "country_code": "CAN",
    "importance": 1,
    "pinyin_full": "wennibo",
    "pinyin_initial": "wnb"
  },
  {
    "name_en": "Calgary",
    "name_zh": "卡尔加里",
    "lat": 51.0447,
    "lon": -114.0719,
    "country_code": "CAN",
    "importance": 1,
    "pinyin_full": "kaerjiali",
    "pinyin_initial": "kejl"
  },
  {
    "name_en": "Vancouver",
    "name_zh": "温哥华",
    "lat": 49.2827,
    "lon": -123.1207,
    "country_code": "CAN",
    "importance": 1,
    "pinyin_full": "wengehua",
    "pinyin_initial": "wgh"
  },
  {
    "name_en": "New Delhi",
    "name_zh": "新德里",
    "lat": 28.6139,
    "lon": 77.209,
    "country_code": "IND",
    "importance": 2,
    "pinyin_full": "xindeli",
    "pinyin_initial": "xdl"
  },
  {
    "name_en": "Mumbai",
    "name_zh": "孟买",
    "lat": 19.076,
    "lon": 72.8777,
    "country_code": "IND",
    "importance": 2,
    "pinyin_full": "mengmai",
    "pinyin_initial": "mm"
  },
  {
    "name_en": "Bangalore",
    "name_zh": "班加罗尔",
    "lat": 12.9716,
    "lon": 77.5946,
    "country_code": "IND",
    "importance": 2,
    "pinyin_full": "banjialuoer",
    "pinyin_initial": "bjle"
  },
  {
    "name_en": "Kolkata",
    "name_zh": "加尔各答",
    "lat": 22.5726,
    "lon": 88.3639,
    "country_code": "IND",
    "importance": 2,
    "pinyin_full": "jiaergeda",
    "pinyin_initial": "jegd"
  },
  {
    "name_en": "Sydney",
    "name_zh": "悉尼",
    "lat": -33.8688,
    "lon": 151.2093,
    "country_code": "AUS",
    "importance": 2,
    "pinyin_full": "xini",
    "pinyin_initial": "xn"
  },
  {
    "name_en": "Melbourne",
    "name_zh": "墨尔本",
    "lat": -37.8136,
    "lon": 144.9631,
    "country_code": "AUS",
    "importance": 2,
    "pinyin_full": "moerben",
    "pinyin_initial": "meb"
  },
  {
    "name_en": "Brisbane",
    "name_zh": "布里斯班",
    "lat": -27.4698,
    "lon": 153.0251,
    "country_code": "AUS",
    "importance": 2,
    "pinyin_full": "bulisiban",
    "pinyin_initial": "blsb"
  },
  {
    "name_en": "Perth",
    "name_zh": "珀斯",
    "lat": -31.9505,
    "lon": 115.8605,
    "country_code": "AUS",
    "importance": 2,
    "pinyin_full": "posi",
    "pinyin_initial": "ps"
  },
  {
    "name_en": "Guam",
    "name_zh": "关岛",
    "lat": 13.4443,
    "lon": 144.7937,
    "country_code": "GUM",
    "importance": 2,
    "pinyin_full": "guandao",
    "pinyin_initial": "gd"
  },
  {
    "name_en": "Puerto Rico",
    "name_zh": "波多黎各",
    "lat": 18.2208,
    "lon": -66.5901,
    "country_code": "PRI",
    "importance": 2,
    "pinyin_full": "boduolige",
    "pinyin_initial": "bdlg"
  },
  {
    "name_en": "Nuuk",
    "name_zh": "努克",
    "lat": 64.1836,
    "lon": -51.7216,
    "country_code": "GRL",
    "importance": 1,
    "pinyin_full": "nuke",
    "pinyin_initial": "nk"
  },
  {
    "name_en": "Nouméa",
    "name_zh": "努美阿",
    "lat": -21.2078,
    "lon": 165.289,
    "country_code": "NCL",
    "importance": 1,
    "pinyin_full": "numeia",
    "pinyin_initial": "nma"
  },
  {
    "name_en": "Stanley",
    "name_zh": "斯坦利",
    "lat": -51.7,
    "lon": -57.85,
    "country_code": "FLK",
    "importance": 1,
    "pinyin_full": "sitanli",
    "pinyin_initial": "stl"
  },
  {
    "name_en": "Saint-Denis",
    "name_zh": "圣但尼",
    "lat": -20.8823,
    "lon": 55.4504,
    "country_code": "REU",
    "importance": 1,
    "pinyin_full": "shengdanni",
    "pinyin_initial": "sdn"
  },
  {
    "name_en": "Fort-de-France",
    "name_zh": "法兰西堡",
    "lat": 14.6049,
    "lon": -61.0718,
    "country_code": "MTQ",
    "importance": 1,
    "pinyin_full": "falanxibao",
    "pinyin_initial": "flxb"
  },
  {
    "name_en": "Tórshavn",
    "name_zh": "托尔斯港",
    "lat": 62.0097,
    "lon": -6.7726,
    "country_code": "FRO",
    "importance": 1,
    "pinyin_full": "tuoersigang",
    "pinyin_initial": "tesg"
  },
  {
    "name_en": "Saipan",
    "name_zh": "塞班",
    "lat": 15.214,
    "lon": 145.756,
    "country_code": "MNP",
    "importance": 1,
    "pinyin_full": "saiban",
    "pinyin_initial": "sb"
  },
  {
    "name_en": "Charlotte Amalie",
    "name_zh": "夏洛特阿马利亚",
    "lat": 18.339,
    "lon": -64.933,
    "country_code": "VIR",
    "importance": 1,
    "pinyin_full": "xialuoteamaliya",
    "pinyin_initial": "xltamly"
  },
  {
    "name_en": "Algiers",
    "name_zh": "阿尔及尔",
    "lat": 36.7528,
    "lon": 3.0422,
    "country_code": "DZA",
    "importance": 1,
    "pinyin_full": "aerjier",
    "pinyin_initial": "aeje"
  },
  {
    "name_en": "Luanda",
    "name_zh": "罗安达",
    "lat": -8.839,
    "lon": 13.2894,
    "country_code": "AGO",
    "importance": 1,
    "pinyin_full": "luoanda",
    "pinyin_initial": "lad"
  },
  {
    "name_en": "Porto-Novo",
    "name_zh": "波多诺伏",
    "lat": 6.4969,
    "lon": 2.6289,
    "country_code": "BEN",
    "importance": 1,
    "pinyin_full": "boduonuofu",
    "pinyin_initial": "bdnf"
  },
  {
    "name_en": "Gaborone",
    "name_zh": "哈博罗内",
    "lat": -24.6581,
    "lon": 25.9122,
    "country_code": "BWA",
    "importance": 1,
    "pinyin_full": "haboluonei",
    "pinyin_initial": "hbln"
  },
  {
    "name_en": "Ouagadougou",
    "name_zh": "瓦加杜古",
    "lat": 12.3642,
    "lon": -1.5383,
    "country_code": "BFA",
    "importance": 1,
    "pinyin_full": "wajiadugu",
    "pinyin_initial": "wjdg"
  },
  {
    "name_en": "Gitega",
    "name_zh": "基特加",
    "lat": -3.4264,
    "lon": 29.9256,
    "country_code": "BDI",
    "importance": 1,
    "pinyin_full": "jitejia",
    "pinyin_initial": "jtj"
  },
  {
    "name_en": "Yaoundé",
    "name_zh": "雅温得",
    "lat": 3.848,
    "lon": 11.5021,
    "country_code": "CMR",
    "importance": 1,
    "pinyin_full": "yawende",
    "pinyin_initial": "ywd"
  },
  {
    "name_en": "Praia",
    "name_zh": "普拉亚",
    "lat": 14.9331,
    "lon": -23.5133,
    "country_code": "CPV",
    "importance": 1,
    "pinyin_full": "pulaya",
    "pinyin_initial": "ply"
  },
  {
    "name_en": "Bangui",
    "name_zh": "班吉",
    "lat": 4.3947,
    "lon": 18.5582,
    "country_code": "CAF",
    "importance": 1,
    "pinyin_full": "banji",
    "pinyin_initial": "bj"
  },
  {
    "name_en": "N'Djamena",
    "name_zh": "恩贾梅纳",
    "lat": 12.1348,
    "lon": 15.0557,
    "country_code": "TCD",
    "importance": 1,
    "pinyin_full": "enjiameina",
    "pinyin_initial": "ejmn"
  },
  {
    "name_en": "Moroni",
    "name_zh": "莫罗尼",
    "lat": -11.6982,
    "lon": 43.2536,
    "country_code": "COM",
    "importance": 1,
    "pinyin_full": "moluoni",
    "pinyin_initial": "mln"
  },
  {
    "name_en": "Kinshasa",
    "name_zh": "金沙萨",
    "lat": -4.325,
    "lon": 15.3222,
    "country_code": "COD",
    "importance": 1,
    "pinyin_full": "jinshasa",
    "pinyin_initial": "jss"
  },
  {
    "name_en": "Brazzaville",
    "name_zh": "布拉柴维尔",
    "lat": -4.2634,
    "lon": 15.2429,
    "country_code": "COG",
    "importance": 1,
    "pinyin_full": "bulachaiweier",
    "pinyin_initial": "blcwe"
  },
  {
    "name_en": "Djibouti",
    "name_zh": "吉布提",
    "lat": 11.589,
    "lon": 43.145,
    "country_code": "DJI",
    "importance": 1,
    "pinyin_full": "jibuti",
    "pinyin_initial": "jbt"
  },
  {
    "name_en": "Cairo",
    "name_zh": "开罗",
    "lat": 30.0444,
    "lon": 31.2357,
    "country_code": "EGY",
    "importance": 1,
    "pinyin_full": "kailuo",
    "pinyin_initial": "kl"
  },
  {
    "name_en": "Malabo",
    "name_zh": "马拉博",
    "lat": 3.75,
    "lon": 8.7833,
    "country_code": "GNQ",
    "importance": 1,
    "pinyin_full": "malabo",
    "pinyin_initial": "mlb"
  },
  {
    "name_en": "Asmara",
    "name_zh": "阿斯马拉",
    "lat": 15.3333,
    "lon": 38.9333,
    "country_code": "ERI",
    "importance": 1,
    "pinyin_full": "asimala",
    "pinyin_initial": "asml"
  },
  {
    "name_en": "Mbabane",
    "name_zh": "姆巴巴内",
    "lat": -26.3054,
    "lon": 31.1367,
    "country_code": "SWZ",
    "importance": 1,
    "pinyin_full": "mubabanei",
    "pinyin_initial": "mbbn"
  },
  {
    "name_en": "Addis Ababa",
    "name_zh": "亚的斯亚贝巴",
    "lat": 9.03,
    "lon": 38.74,
    "country_code": "ETH",
    "importance": 1,
    "pinyin_full": "yadesiyabeiba",
    "pinyin_initial": "ydsybb"
  },
  {
    "name_en": "Libreville",
    "name_zh": "利伯维尔",
    "lat": 0.3901,
    "lon": 9.4544,
    "country_code": "GAB",
    "importance": 1,
    "pinyin_full": "liboweier",
    "pinyin_initial": "lbwe"
  },
  {
    "name_en": "Banjul",
    "name_zh": "班珠尔",
    "lat": 13.4549,
    "lon": -16.579,
    "country_code": "GMB",
    "importance": 1,
    "pinyin_full": "banzhuer",
    "pinyin_initial": "bze"
  },
  {
    "name_en": "Conakry",
    "name_zh": "科纳克里",
    "lat": 9.6412,
    "lon": -13.5784,
    "country_code": "GIN",
    "importance": 1,
    "pinyin_full": "kenakeli",
    "pinyin_initial": "knkl"
  },
  {
    "name_en": "Bissau",
    "name_zh": "比绍",
    "lat": 11.8636,
    "lon": -15.5977,
    "country_code": "GNB",
    "importance": 1,
    "pinyin_full": "bishao",
    "pinyin_initial": "bs"
  },
  {
    "name_en": "Monrovia",
    "name_zh": "蒙罗维亚",
    "lat": 6.3133,
    "lon": -10.8014,
    "country_code": "LBR",
    "importance": 1,
    "pinyin_full": "mengluoweiya",
    "pinyin_initial": "mlwy"
  },
  {
    "name_en": "Tripoli",
    "name_zh": "的黎波里",
    "lat": 32.8872,
    "lon": 13.1913,
    "country_code": "LBY",
    "importance": 1,
    "pinyin_full": "deliboli",
    "pinyin_initial": "dlbl"
  },
  {
    "name_en": "Antananarivo",
    "name_zh": "塔那那利佛",
    "lat": -18.8792,
    "lon": 47.5079,
    "country_code": "MDG",
    "importance": 1,
    "pinyin_full": "tananalifo",
    "pinyin_initial": "tnnlf"
  },
  {
    "name_en": "Lilongwe",
    "name_zh": "利隆圭",
    "lat": -13.9626,
    "lon": 33.7741,
    "country_code": "MWI",
    "importance": 1,
    "pinyin_full": "lilonggui",
    "pinyin_initial": "llg"
  },
  {
    "name_en": "Bamako",
    "name_zh": "巴马科",
    "lat": 12.6392,
    "lon": -8.0029,
    "country_code": "MLI",
    "importance": 1,
    "pinyin_full": "bamake",
    "pinyin_initial": "bmk"
  },
  {
    "name_en": "Nouakchott",
    "name_zh": "努瓦克肖特",
    "lat": 18.0783,
    "lon": -15.9744,
    "country_code": "MRT",
    "importance": 1,
    "pinyin_full": "nuwakexiaote",
    "pinyin_initial": "nwkxt"
  },
  {
    "name_en": "Port Louis",
    "name_zh": "路易港",
    "lat": -20.1609,
    "lon": 57.5012,
    "country_code": "MUS",
    "importance": 1,
    "pinyin_full": "luyigang",
    "pinyin_initial": "lyg"
  },
  {
    "name_en": "Maputo",
    "name_zh": "马普托",
    "lat": -25.9692,
    "lon": 32.5732,
    "country_code": "MOZ",
    "importance": 1,
    "pinyin_full": "maputuo",
    "pinyin_initial": "mpt"
  },
  {
    "name_en": "Windhoek",
    "name_zh": "温得和克",
    "lat": -22.5597,
    "lon": 17.0832,
    "country_code": "NAM",
    "importance": 1,
    "pinyin_full": "wendeheke",
    "pinyin_initial": "wdhk"
  },
  {
    "name_en": "Niamey",
    "name_zh": "尼亚美",
    "lat": 13.5128,
    "lon": 2.1126,
    "country_code": "NER",
    "importance": 1,
    "pinyin_full": "niyamei",
    "pinyin_initial": "nym"
  },
  {
    "name_en": "Abuja",
    "name_zh": "阿布贾",
    "lat": 9.0579,
    "lon": 7.4951,
    "country_code": "NGA",
    "importance": 1,
    "pinyin_full": "abujia",
    "pinyin_initial": "abj"
  },
  {
    "name_en": "Nairobi",
    "name_zh": "内罗毕",
    "lat": -1.2921,
    "lon": 36.8219,
    "country_code": "KEN",
    "importance": 1,
    "pinyin_full": "neiluobi",
    "pinyin_initial": "nlb"
  },
  {
    "name_en": "Maseru",
    "name_zh": "马塞卢",
    "lat": -29.3158,
    "lon": 27.4854,
    "country_code": "LSO",
    "importance": 1,
    "pinyin_full": "masailu",
    "pinyin_initial": "msl"
  },
  {
    "name_en": "Rabat",
    "name_zh": "拉巴特",
    "lat": 34.0209,
    "lon": -6.8416,
    "country_code": "MAR",
    "importance": 1,
    "pinyin_full": "labate",
    "pinyin_initial": "lbt"
  },
  {
    "name_en": "Kigali",
    "name_zh": "基加利",
    "lat": -2.154,
    "lon": 30.535,
    "country_code": "RWA",
    "importance": 1,
    "pinyin_full": "jijiali",
    "pinyin_initial": "jjl"
  },
  {
    "name_en": "Sao Tome",
    "name_zh": "圣多美",
    "lat": 0.3365,
    "lon": 6.7273,
    "country_code": "STP",
    "importance": 1,
    "pinyin_full": "shengduomei",
    "pinyin_initial": "sdm"
  },
  {
    "name_en": "Dakar",
    "name_zh": "达喀尔",
    "lat": 14.6928,
    "lon": -17.4467,
    "country_code": "SEN",
    "importance": 1,
    "pinyin_full": "dakaer",
    "pinyin_initial": "dke"
  },
  {
    "name_en": "Victoria",
    "name_zh": "维多利亚",
    "lat": -4.6191,
    "lon": 55.4513,
    "country_code": "SYC",
    "importance": 1,
    "pinyin_full": "weiduoliya",
    "pinyin_initial": "wdly"
  },
  {
    "name_en": "Freetown",
    "name_zh": "弗里敦",
    "lat": 8.4657,
    "lon": -13.2317,
    "country_code": "SLE",
    "importance": 1,
    "pinyin_full": "fulidun",
    "pinyin_initial": "fld"
  },
  {
    "name_en": "Mogadishu",
    "name_zh": "摩加迪沙",
    "lat": 2.0469,
    "lon": 45.3182,
    "country_code": "SOM",
    "importance": 1,
    "pinyin_full": "mojiadisha",
    "pinyin_initial": "mjds"
  },
  {
    "name_en": "Pretoria",
    "name_zh": "比勒陀利亚",
    "lat": -25.7461,
    "lon": 28.1881,
    "country_code": "ZAF",
    "importance": 1,
    "pinyin_full": "biletuoliya",
    "pinyin_initial": "bltly"
  },
  {
    "name_en": "Cape Town",
    "name_zh": "开普敦",
    "lat": -33.9258,
    "lon": 18.4232,
    "country_code": "ZAF",
    "importance": 0.5,
    "pinyin_full": "kaipudun",
    "pinyin_initial": "kpd"
  },
  {
    "name_en": "Bloemfontein",
    "name_zh": "布隆方丹",
    "lat": -29.1184,
    "lon": 26.2294,
    "country_code": "ZAF",
    "importance": 0.5,
    "pinyin_full": "bulongfangdan",
    "pinyin_initial": "blfd"
  },
  {
    "name_en": "Juba",
    "name_zh": "朱巴",
    "lat": 4.8594,
    "lon": 31.5713,
    "country_code": "SSD",
    "importance": 1,
    "pinyin_full": "zhuba",
    "pinyin_initial": "zb"
  },
  {
    "name_en": "Khartoum",
    "name_zh": "喀土穆",
    "lat": 15.5007,
    "lon": 32.5599,
    "country_code": "SDN",
    "importance": 1,
    "pinyin_full": "katumu",
    "pinyin_initial": "ktm"
  },
  {
    "name_en": "Dodoma",
    "name_zh": "多多马",
    "lat": -6.163,
    "lon": 35.7516,
    "country_code": "TZA",
    "importance": 1,
    "pinyin_full": "duoduoma",
    "pinyin_initial": "ddm"
  },
  {
    "name_en": "Lomé",
    "name_zh": "洛美",
    "lat": 6.1319,
    "lon": 1.222,
    "country_code": "TGO",
    "importance": 1,
    "pinyin_full": "luomei",
    "pinyin_initial": "lm"
  },
  {
    "name_en": "Tunis",
    "name_zh": "突尼斯",
    "lat": 36.8065,
    "lon": 10.1815,
    "country_code": "TUN",
    "importance": 1,
    "pinyin_full": "tunisi",
    "pinyin_initial": "tns"
  },
  {
    "name_en": "Kampala",
    "name_zh": "坎帕拉",
    "lat": 0.3476,
    "lon": 32.5825,
    "country_code": "UGA",
    "importance": 1,
    "pinyin_full": "kanpala",
    "pinyin_initial": "kpl"
  },
  {
    "name_en": "Lusaka",
    "name_zh": "卢萨卡",
    "lat": -15.4167,
    "lon": 28.2833,
    "country_code": "ZMB",
    "importance": 1,
    "pinyin_full": "lusaka",
    "pinyin_initial": "lsk"
  },
  {
    "name_en": "Harare",
    "name_zh": "哈拉雷",
    "lat": -17.8292,
    "lon": 31.0522,
    "country_code": "ZWE",
    "importance": 1,
    "pinyin_full": "halalei",
    "pinyin_initial": "hll"
  },
  {
    "name_en": "Yamoussoukro",
    "name_zh": "亚穆苏克罗",
    "lat": 7.546,
    "lon": -5.5471,
    "country_code": "CIV",
    "importance": 1,
    "pinyin_full": "yamusukeluo",
    "pinyin_initial": "ymskl"
  },
  {
    "name_en": "Accra",
    "name_zh": "阿克拉",
    "lat": 5.6037,
    "lon": -0.187,
    "country_code": "GHA",
    "importance": 1,
    "pinyin_full": "akela",
    "pinyin_initial": "akl"
  },
  {
    "name_en": "Kabul",
    "name_zh": "喀布尔",
    "lat": 34.5553,
    "lon": 69.2075,
    "country_code": "AFG",
    "importance": 1,
    "pinyin_full": "kabuer",
    "pinyin_initial": "kbe"
  },
  {
    "name_en": "Yerevan",
    "name_zh": "埃里温",
    "lat": 40.1792,
    "lon": 44.4991,
    "country_code": "ARM",
    "importance": 1,
    "pinyin_full": "ailiwen",
    "pinyin_initial": "alw"
  },
  {
    "name_en": "Baku",
    "name_zh": "巴库",
    "lat": 40.4093,
    "lon": 49.8671,
    "country_code": "AZE",
    "importance": 1,
    "pinyin_full": "baku",
    "pinyin_initial": "bk"
  },
  {
    "name_en": "Manama",
    "name_zh": "麦纳麦",
    "lat": 26.2285,
    "lon": 50.586,
    "country_code": "BHR",
    "importance": 1,
    "pinyin_full": "mainamai",
    "pinyin_initial": "mnm"
  },
  {
    "name_en": "Dhaka",
    "name_zh": "达卡",
    "lat": 23.8103,
    "lon": 90.4125,
    "country_code": "BGD",
    "importance": 1,
    "pinyin_full": "daka",
    "pinyin_initial": "dk"
  },
  {
    "name_en": "Thimphu",
    "name_zh": "廷布",
    "lat": 27.4728,
    "lon": 89.639,
    "country_code": "BTN",
    "importance": 1,
    "pinyin_full": "tingbu",
    "pinyin_initial": "tb"
  },
  {
    "name_en": "Bandar Seri Begawan",
    "name_zh": "斯里巴加湾市",
    "lat": 4.9031,
    "lon": 114.9398,
    "country_code": "BRN",
    "importance": 1,
    "pinyin_full": "silibajiawanshi",
    "pinyin_initial": "slbjws"
  },
  {
    "name_en": "Phnom Penh",
    "name_zh": "金边",
    "lat": 12.5657,
    "lon": 104.991,
    "country_code": "KHM",
    "importance": 1,
    "pinyin_full": "jinbian",
    "pinyin_initial": "jb"
  },
  {
    "name_en": "Nicosia",
    "name_zh": "尼科西亚",
    "lat": 35.1796,
    "lon": 33.3823,
    "country_code": "CYP",
    "importance": 1,
    "pinyin_full": "nikexiya",
    "pinyin_initial": "nkxy"
  },
  {
    "name_en": "Tbilisi",
    "name_zh": "第比利斯",
    "lat": 41.7151,
    "lon": 44.8271,
    "country_code": "GEO",
    "importance": 1,
    "pinyin_full": "dibilisi",
    "pinyin_initial": "dbls"
  },
  {
    "name_en": "New Delhi",
    "name_zh": "新德里",
    "lat": 28.6139,
    "lon": 77.209,
    "country_code": "IND",
    "importance": 1,
    "pinyin_full": "xindeli",
    "pinyin_initial": "xdl"
  },
  {
    "name_en": "Jakarta",
    "name_zh": "雅加达",
    "lat": -6.2088,
    "lon": 106.8456,
    "country_code": "IDN",
    "importance": 1,
    "pinyin_full": "yajiada",
    "pinyin_initial": "yjd"
  },
  {
    "name_en": "Tehran",
    "name_zh": "德黑兰",
    "lat": 35.6892,
    "lon": 51.389,
    "country_code": "IRN",
    "importance": 1,
    "pinyin_full": "deheilan",
    "pinyin_initial": "dhl"
  },
  {
    "name_en": "Baghdad",
    "name_zh": "巴格达",
    "lat": 33.3152,
    "lon": 44.3661,
    "country_code": "IRQ",
    "importance": 1,
    "pinyin_full": "bageda",
    "pinyin_initial": "bgd"
  },
  {
    "name_en": "Jerusalem",
    "name_zh": "耶路撒冷",
    "lat": 31.7683,
    "lon": 35.2137,
    "country_code": "ISR",
    "importance": 1,
    "pinyin_full": "yelusaleng",
    "pinyin_initial": "ylsl"
  },
  {
    "name_en": "Tokyo",
    "name_zh": "东京",
    "lat": 35.6895,
    "lon": 139.6917,
    "country_code": "JPN",
    "importance": 1,
    "pinyin_full": "dongjing",
    "pinyin_initial": "dj"
  },
  {
    "name_en": "Amman",
    "name_zh": "安曼",
    "lat": 31.9632,
    "lon": 35.9304,
    "country_code": "JOR",
    "importance": 1,
    "pinyin_full": "anman",
    "pinyin_initial": "am"
  },
  {
    "name_en": "Astana",
    "name_zh": "阿斯塔纳",
    "lat": 51.1694,
    "lon": 71.4491,
    "country_code": "KAZ",
    "importance": 1,
    "pinyin_full": "asitana",
    "pinyin_initial": "astn"
  },
  {
    "name_en": "Kuwait City",
    "name_zh": "科威特城",
    "lat": 29.3759,
    "lon": 47.9774,
    "country_code": "KWT",
    "importance": 1,
    "pinyin_full": "keweitecheng",
    "pinyin_initial": "kwtc"
  },
  {
    "name_en": "Bishkek",
    "name_zh": "比什凯克",
    "lat": 42.8746,
    "lon": 74.6122,
    "country_code": "KGZ",
    "importance": 1,
    "pinyin_full": "bishenkaike",
    "pinyin_initial": "bskk"
  },
  {
    "name_en": "Vientiane",
    "name_zh": "万象",
    "lat": 17.9757,
    "lon": 102.6331,
    "country_code": "LAO",
    "importance": 1,
    "pinyin_full": "wanxiang",
    "pinyin_initial": "wx"
  },
  {
    "name_en": "Beirut",
    "name_zh": "贝鲁特",
    "lat": 33.8938,
    "lon": 35.5018,
    "country_code": "LBN",
    "importance": 1,
    "pinyin_full": "beilute",
    "pinyin_initial": "blt"
  },
  {
    "name_en": "Kuala Lumpur",
    "name_zh": "吉隆坡",
    "lat": 3.139,
    "lon": 101.6869,
    "country_code": "MYS",
    "importance": 1,
    "pinyin_full": "jilongpo",
    "pinyin_initial": "jlp"
  },
  {
    "name_en": "Malé",
    "name_zh": "马累",
    "lat": 4.1755,
    "lon": 73.5093,
    "country_code": "MDV",
    "importance": 1,
    "pinyin_full": "malei",
    "pinyin_initial": "ml"
  },
  {
    "name_en": "Ulaanbaatar",
    "name_zh": "乌兰巴托",
    "lat": 47.8864,
    "lon": 106.9057,
    "country_code": "MNG",
    "importance": 1,
    "pinyin_full": "wulanbatuo",
    "pinyin_initial": "wlbt"
  },
  {
    "name_en": "Naypyidaw",
    "name_zh": "内比都",
    "lat": 21.9162,
    "lon": 95.956,
    "country_code": "MMR",
    "importance": 1,
    "pinyin_full": "neibidou",
    "pinyin_initial": "nbd"
  },
  {
    "name_en": "Kathmandu",
    "name_zh": "加德满都",
    "lat": 27.7172,
    "lon": 85.324,
    "country_code": "NPL",
    "importance": 1,
    "pinyin_full": "jiademandou",
    "pinyin_initial": "jdmd"
  },
  {
    "name_en": "Pyongyang",
    "name_zh": "平壤",
    "lat": 39.0392,
    "lon": 125.7625,
    "country_code": "PRK",
    "importance": 1,
    "pinyin_full": "pingrang",
    "pinyin_initial": "pr"
  },
  {
    "name_en": "Seoul",
    "name_zh": "首尔",
    "lat": 37.5665,
    "lon": 126.978,
    "country_code": "KOR",
    "importance": 1,
    "pinyin_full": "shouer",
    "pinyin_initial": "se"
  },
  {
    "name_en": "Muscat",
    "name_zh": "马斯喀特",
    "lat": 23.6139,
    "lon": 58.5922,
    "country_code": "OMN",
    "importance": 1,
    "pinyin_full": "masikate",
    "pinyin_initial": "mskt"
  },
  {
    "name_en": "Islamabad",
    "name_zh": "伊斯兰堡",
    "lat": 33.6844,
    "lon": 73.0479,
    "country_code": "PAK",
    "importance": 1,
    "pinyin_full": "yisilanbao",
    "pinyin_initial": "yslb"
  },
  {
    "name_en": "Manila",
    "name_zh": "马尼拉",
    "lat": 14.5995,
    "lon": 120.9842,
    "country_code": "PHL",
    "importance": 1,
    "pinyin_full": "manila",
    "pinyin_initial": "mnl"
  },
  {
    "name_en": "Doha",
    "name_zh": "多哈",
    "lat": 25.2854,
    "lon": 51.531,
    "country_code": "QAT",
    "importance": 1,
    "pinyin_full": "duoha",
    "pinyin_initial": "dh"
  },
  {
    "name_en": "Riyadh",
    "name_zh": "利雅得",
    "lat": 24.7136,
    "lon": 46.6753,
    "country_code": "SAU",
    "importance": 1,
    "pinyin_full": "liyade",
    "pinyin_initial": "lyd"
  },
  {
    "name_en": "Singapore",
    "name_zh": "新加坡",
    "lat": 1.3521,
    "lon": 103.8198,
    "country_code": "SGP",
    "importance": 1,
    "pinyin_full": "xinjiapo",
    "pinyin_initial": "xjp"
  },
  {
    "name_en": "Colombo",
    "name_zh": "科伦坡",
    "lat": 6.9271,
    "lon": 79.8612,
    "country_code": "LKA",
    "importance": 1,
    "pinyin_full": "kelunpo",
    "pinyin_initial": "klp"
  },
  {
    "name_en": "Damascus",
    "name_zh": "大马士革",
    "lat": 33.5138,
    "lon": 36.2765,
    "country_code": "SYR",
    "importance": 1,
    "pinyin_full": "damashige",
    "pinyin_initial": "dmsg"
  },
  {
    "name_en": "Taipei",
    "name_zh": "台北",
    "lat": 24.1477,
    "lon": 120.6736,
    "country_code": "TWN",
    "importance": 1,
    "pinyin_full": "taibei",
    "pinyin_initial": "tb"
  },
  {
    "name_en": "Dushanbe",
    "name_zh": "杜尚别",
    "lat": 38.5598,
    "lon": 68.787,
    "country_code": "TJK",
    "importance": 1,
    "pinyin_full": "dushangbie",
    "pinyin_initial": "dsb"
  },
  {
    "name_en": "Bangkok",
    "name_zh": "曼谷",
    "lat": 13.7563,
    "lon": 100.5018,
    "country_code": "THA",
    "importance": 1,
    "pinyin_full": "mangu",
    "pinyin_initial": "mg"
  },
  {
    "name_en": "Dili",
    "name_zh": "帝力",
    "lat": -8.5569,
    "lon": 125.5603,
    "country_code": "TLS",
    "importance": 1,
    "pinyin_full": "dili",
    "pinyin_initial": "dl"
  },
  {
    "name_en": "Ankara",
    "name_zh": "安卡拉",
    "lat": 39.9334,
    "lon": 32.8597,
    "country_code": "TUR",
    "importance": 1,
    "pinyin_full": "ankala",
    "pinyin_initial": "akl"
  },
  {
    "name_en": "Ashgabat",
    "name_zh": "阿什哈巴德",
    "lat": 37.9601,
    "lon": 58.3261,
    "country_code": "TKM",
    "importance": 1,
    "pinyin_full": "ashenhabade",
    "pinyin_initial": "ashbd"
  },
  {
    "name_en": "Abu Dhabi",
    "name_zh": "阿布扎比",
    "lat": 24.4539,
    "lon": 54.3773,
    "country_code": "ARE",
    "importance": 1,
    "pinyin_full": "abuzhabi",
    "pinyin_initial": "abzb"
  },
  {
    "name_en": "Tashkent",
    "name_zh": "塔什干",
    "lat": 41.2995,
    "lon": 69.2401,
    "country_code": "UZB",
    "importance": 1,
    "pinyin_full": "tashigan",
    "pinyin_initial": "tsg"
  },
  {
    "name_en": "Hanoi",
    "name_zh": "河内",
    "lat": 21.0285,
    "lon": 105.8542,
    "country_code": "VNM",
    "importance": 1,
    "pinyin_full": "henei",
    "pinyin_initial": "hn"
  },
  {
    "name_en": "Sana'a",
    "name_zh": "萨那",
    "lat": 15.3694,
    "lon": 44.191,
    "country_code": "YEM",
    "importance": 1,
    "pinyin_full": "sana",
    "pinyin_initial": "sn"
  },
  {
    "name_en": "Moscow",
    "name_zh": "莫斯科",
    "lat": 55.7558,
    "lon": 37.6173,
    "country_code": "RUS",
    "importance": 1,
    "pinyin_full": "mosike",
    "pinyin_initial": "msk"
  },
  {
    "name_en": "Port Moresby",
    "name_zh": "莫尔兹比港",
    "lat": -9.4438,
    "lon": 147.1803,
    "country_code": "PNG",
    "importance": 1,
    "pinyin_full": "moerzibigang",
    "pinyin_initial": "mezbg"
  },
  {
    "name_en": "Funafuti",
    "name_zh": "富纳富提",
    "lat": -8.5188,
    "lon": 179.1983,
    "country_code": "TUV",
    "importance": 1,
    "pinyin_full": "funafuti",
    "pinyin_initial": "fnft"
  },
  {
    "name_en": "Apia",
    "name_zh": "阿皮亚",
    "lat": -13.8333,
    "lon": -171.7667,
    "country_code": "WSM",
    "importance": 1,
    "pinyin_full": "apiya",
    "pinyin_initial": "apy"
  },
  {
    "name_en": "Nuku'alofa",
    "name_zh": "努库阿洛法",
    "lat": -21.2078,
    "lon": -175.1982,
    "country_code": "TON",
    "importance": 1,
    "pinyin_full": "nukualuofa",
    "pinyin_initial": "nkalf"
  },
  {
    "name_en": "Palikir",
    "name_zh": "帕利基尔",
    "lat": 7.4255,
    "lon": 151.85,
    "country_code": "FSM",
    "importance": 1,
    "pinyin_full": "palijier",
    "pinyin_initial": "plje"
  },
  {
    "name_en": "Honiara",
    "name_zh": "霍尼亚拉",
    "lat": -9.531,
    "lon": 159.95,
    "country_code": "SLB",
    "importance": 1,
    "pinyin_full": "huoniyala",
    "pinyin_initial": "hnyl"
  },
  {
    "name_en": "Port Vila",
    "name_zh": "维拉港",
    "lat": -15.483,
    "lon": 166.95,
    "country_code": "VUT",
    "importance": 1,
    "pinyin_full": "weilagang",
    "pinyin_initial": "wlg"
  },
  {
    "name_en": "Majuro",
    "name_zh": "马朱罗",
    "lat": 7.116,
    "lon": 171.383,
    "country_code": "MHL",
    "importance": 1,
    "pinyin_full": "mazhuluo",
    "pinyin_initial": "mzl"
  },
  {
    "name_en": "Yaren",
    "name_zh": "亚伦",
    "lat": 0.522,
    "lon": 166.931,
    "country_code": "NRU",
    "importance": 1,
    "pinyin_full": "yalun",
    "pinyin_initial": "yl"
  },
  {
    "name_en": "South Tarawa",
    "name_zh": "南塔拉瓦",
    "lat": -0.216,
    "lon": 173.15,
    "country_code": "KIR",
    "importance": 1,
    "pinyin_full": "nantalawa",
    "pinyin_initial": "ntlw"
  },
  {
    "name_en": "Ngerulmud",
    "name_zh": "恩吉鲁穆德",
    "lat": 7.4255,
    "lon": 134.475,
    "country_code": "PLW",
    "importance": 1,
    "pinyin_full": "enjilumude",
    "pinyin_initial": "ejlmd"
  },
  {
    "name_en": "Tirana",
    "name_zh": "地拉那",
    "lat": 41.3275,
    "lon": 19.8187,
    "country_code": "ALB",
    "importance": 1,
    "pinyin_full": "dilana",
    "pinyin_initial": "dln"
  },
  {
    "name_en": "Pristina",
    "name_zh": "普里什蒂纳",
    "lat": 42.6629,
    "lon": 21.1655,
    "country_code": "KOS",
    "importance": 1,
    "pinyin_full": "pulishendina",
    "pinyin_initial": "plsdn"
  },
  {
    "name_en": "Vienna",
    "name_zh": "维也纳",
    "lat": 48.2082,
    "lon": 16.3738,
    "country_code": "AUT",
    "importance": 1,
    "pinyin_full": "weiyena",
    "pinyin_initial": "wyn"
  },
  {
    "name_en": "Minsk",
    "name_zh": "明斯克",
    "lat": 53.9045,
    "lon": 27.5615,
    "country_code": "BLR",
    "importance": 1,
    "pinyin_full": "mingsike",
    "pinyin_initial": "msk"
  },
  {
    "name_en": "Sarajevo",
    "name_zh": "萨拉热窝",
    "lat": 43.8563,
    "lon": 18.4131,
    "country_code": "BIH",
    "importance": 1,
    "pinyin_full": "salarewo",
    "pinyin_initial": "slrw"
  },
  {
    "name_en": "Sofia",
    "name_zh": "索非亚",
    "lat": 42.6977,
    "lon": 23.3219,
    "country_code": "BGR",
    "importance": 1,
    "pinyin_full": "suofeiya",
    "pinyin_initial": "sfy"
  },
  {
    "name_en": "Zagreb",
    "name_zh": "萨格勒布",
    "lat": 45.815,
    "lon": 15.9819,
    "country_code": "HRV",
    "importance": 1,
    "pinyin_full": "sagelebu",
    "pinyin_initial": "sglb"
  },
  {
    "name_en": "Prague",
    "name_zh": "布拉格",
    "lat": 50.0755,
    "lon": 14.4378,
    "country_code": "CZE",
    "importance": 1,
    "pinyin_full": "bulage",
    "pinyin_initial": "blg"
  },
  {
    "name_en": "Copenhagen",
    "name_zh": "哥本哈根",
    "lat": 55.6761,
    "lon": 12.5683,
    "country_code": "DNK",
    "importance": 1,
    "pinyin_full": "gebenhagen",
    "pinyin_initial": "gbhg"
  },
  {
    "name_en": "Tallinn",
    "name_zh": "塔林",
    "lat": 59.437,
    "lon": 24.7536,
    "country_code": "EST",
    "importance": 1,
    "pinyin_full": "talin",
    "pinyin_initial": "tl"
  },
  {
    "name_en": "Helsinki",
    "name_zh": "赫尔辛基",
    "lat": 60.1699,
    "lon": 24.9384,
    "country_code": "FIN",
    "importance": 1,
    "pinyin_full": "heerxinji",
    "pinyin_initial": "hexj"
  },
  {
    "name_en": "Athens",
    "name_zh": "雅典",
    "lat": 37.9838,
    "lon": 23.7275,
    "country_code": "GRC",
    "importance": 1,
    "pinyin_full": "yadian",
    "pinyin_initial": "yd"
  },
  {
    "name_en": "Reykjavik",
    "name_zh": "雷克雅未克",
    "lat": 64.1466,
    "lon": -21.9426,
    "country_code": "ISL",
    "importance": 1,
    "pinyin_full": "leikeyaweike",
    "pinyin_initial": "lkywk"
  },
  {
    "name_en": "Riga",
    "name_zh": "里加",
    "lat": 56.9496,
    "lon": 24.1052,
    "country_code": "LVA",
    "importance": 1,
    "pinyin_full": "lijia",
    "pinyin_initial": "lj"
  },
  {
    "name_en": "Vaduz",
    "name_zh": "瓦杜兹",
    "lat": 47.0169,
    "lon": 9.5228,
    "country_code": "LIE",
    "importance": 1,
    "pinyin_full": "waduzi",
    "pinyin_initial": "wdz"
  },
  {
    "name_en": "Vilnius",
    "name_zh": "维尔纽斯",
    "lat": 54.6872,
    "lon": 25.2797,
    "country_code": "LTU",
    "importance": 1,
    "pinyin_full": "weierniusi",
    "pinyin_initial": "wens"
  },
  {
    "name_en": "Luxembourg",
    "name_zh": "卢森堡",
    "lat": 49.6116,
    "lon": 6.1319,
    "country_code": "LUX",
    "importance": 1,
    "pinyin_full": "lusenbao",
    "pinyin_initial": "lsb"
  },
  {
    "name_en": "Valletta",
    "name_zh": "瓦莱塔",
    "lat": 35.8989,
    "lon": 14.5146,
    "country_code": "MLT",
    "importance": 1,
    "pinyin_full": "walaita",
    "pinyin_initial": "wlt"
  },
  {
    "name_en": "Chișinău",
    "name_zh": "基希讷乌",
    "lat": 47.0707,
    "lon": 28.8638,
    "country_code": "MDA",
    "importance": 1,
    "pinyin_full": "jixinewu",
    "pinyin_initial": "jxnw"
  },
  {
    "name_en": "Podgorica",
    "name_zh": "波德戈里察",
    "lat": 43.1777,
    "lon": 19.263,
    "country_code": "MNE",
    "importance": 1,
    "pinyin_full": "bodegelicha",
    "pinyin_initial": "bdglc"
  },
  {
    "name_en": "Skopje",
    "name_zh": "斯科普里",
    "lat": 42.0983,
    "lon": 21.4314,
    "country_code": "MKD",
    "importance": 1,
    "pinyin_full": "sikepuli",
    "pinyin_initial": "skpl"
  },
  {
    "name_en": "Oslo",
    "name_zh": "奥斯陆",
    "lat": 59.9139,
    "lon": 10.7522,
    "country_code": "NOR",
    "importance": 1,
    "pinyin_full": "aosilu",
    "pinyin_initial": "asl"
  },
  {
    "name_en": "Lisbon",
    "name_zh": "里斯本",
    "lat": 38.7223,
    "lon": -9.1393,
    "country_code": "PRT",
    "importance": 1,
    "pinyin_full": "lisiben",
    "pinyin_initial": "lsb"
  },
  {
    "name_en": "Belgrade",
    "name_zh": "贝尔格莱德",
    "lat": 44.7866,
    "lon": 20.4489,
    "country_code": "SRB",
    "importance": 1,
    "pinyin_full": "beiergelaide",
    "pinyin_initial": "begld"
  },
  {
    "name_en": "Ljubljana",
    "name_zh": "卢布尔雅那",
    "lat": 46.0569,
    "lon": 14.5058,
    "country_code": "SVN",
    "importance": 1,
    "pinyin_full": "lubueryana",
    "pinyin_initial": "lbeyn"
  },
  {
    "name_en": "Stockholm",
    "name_zh": "斯德哥尔摩",
    "lat": 59.3293,
    "lon": 18.0686,
    "country_code": "SWE",
    "importance": 1,
    "pinyin_full": "sidegeermo",
    "pinyin_initial": "sdgem"
  },
  {
    "name_en": "Andorra la Vella",
    "name_zh": "安道尔城",
    "lat": 42.5063,
    "lon": 1.5218,
    "country_code": "AND",
    "importance": 1,
    "pinyin_full": "andaoercheng",
    "pinyin_initial": "adec"
  },
  {
    "name_en": "Brussels",
    "name_zh": "布鲁塞尔",
    "lat": 50.8503,
    "lon": 4.3517,
    "country_code": "BEL",
    "importance": 1,
    "pinyin_full": "bulusaier",
    "pinyin_initial": "blse"
  },
  {
    "name_en": "Nicosia",
    "name_zh": "尼科西亚",
    "lat": 35.1796,
    "lon": 33.3823,
    "country_code": "CYP",
    "importance": 1,
    "pinyin_full": "nikexiya",
    "pinyin_initial": "nkxy"
  },
  {
    "name_en": "Paris",
    "name_zh": "巴黎",
    "lat": 48.8566,
    "lon": 2.3522,
    "country_code": "FRA",
    "importance": 1,
    "pinyin_full": "bali",
    "pinyin_initial": "bl"
  },
  {
    "name_en": "Berlin",
    "name_zh": "柏林",
    "lat": 52.52,
    "lon": 13.405,
    "country_code": "DEU",
    "importance": 1,
    "pinyin_full": "bolin",
    "pinyin_initial": "bl"
  },
  {
    "name_en": "Budapest",
    "name_zh": "布达佩斯",
    "lat": 47.4979,
    "lon": 19.0402,
    "country_code": "HUN",
    "importance": 1,
    "pinyin_full": "budapeisi",
    "pinyin_initial": "bdps"
  },
  {
    "name_en": "Dublin",
    "name_zh": "都柏林",
    "lat": 53.3498,
    "lon": -6.2603,
    "country_code": "IRL",
    "importance": 1,
    "pinyin_full": "doubolin",
    "pinyin_initial": "dbl"
  },
  {
    "name_en": "Rome",
    "name_zh": "罗马",
    "lat": 41.9028,
    "lon": 12.4964,
    "country_code": "ITA",
    "importance": 1,
    "pinyin_full": "luoma",
    "pinyin_initial": "lm"
  },
  {
    "name_en": "Monaco",
    "name_zh": "摩纳哥",
    "lat": 43.7384,
    "lon": 7.4246,
    "country_code": "MCO",
    "importance": 1,
    "pinyin_full": "monage",
    "pinyin_initial": "mng"
  },
  {
    "name_en": "Amsterdam",
    "name_zh": "阿姆斯特丹",
    "lat": 52.3676,
    "lon": 4.9041,
    "country_code": "NLD",
    "importance": 1,
    "pinyin_full": "amusitedan",
    "pinyin_initial": "amstd"
  },
  {
    "name_en": "Warsaw",
    "name_zh": "华沙",
    "lat": 52.2297,
    "lon": 21.0122,
    "country_code": "POL",
    "importance": 1,
    "pinyin_full": "huasha",
    "pinyin_initial": "hs"
  },
  {
    "name_en": "Bucharest",
    "name_zh": "布加勒斯特",
    "lat": 44.4268,
    "lon": 26.1025,
    "country_code": "ROU",
    "importance": 1,
    "pinyin_full": "bujialesite",
    "pinyin_initial": "bjlst"
  },
  {
    "name_en": "San Marino",
    "name_zh": "圣马力诺",
    "lat": 43.9356,
    "lon": 12.4473,
    "country_code": "SMR",
    "importance": 1,
    "pinyin_full": "shengmalinuo",
    "pinyin_initial": "smln"
  },
  {
    "name_en": "Bratislava",
    "name_zh": "布拉迪斯拉发",
    "lat": 48.1486,
    "lon": 17.1077,
    "country_code": "SVK",
    "importance": 1,
    "pinyin_full": "buladisilafa",
    "pinyin_initial": "bldslf"
  },
  {
    "name_en": "Madrid",
    "name_zh": "马德里",
    "lat": 40.4168,
    "lon": -3.7038,
    "country_code": "ESP",
    "importance": 1,
    "pinyin_full": "madeli",
    "pinyin_initial": "mdl"
  },
  {
    "name_en": "Bern",
    "name_zh": "伯尔尼",
    "lat": 46.948,
    "lon": 7.4474,
    "country_code": "CHE",
    "importance": 1,
    "pinyin_full": "boerni",
    "pinyin_initial": "ben"
  },
  {
    "name_en": "Kyiv",
    "name_zh": "基辅",
    "lat": 50.4501,
    "lon": 30.5234,
    "country_code": "UKR",
    "importance": 1,
    "pinyin_full": "jifu",
    "pinyin_initial": "jf"
  },
  {
    "name_en": "London",
    "name_zh": "伦敦",
    "lat": 51.5072,
    "lon": -0.1276,
    "country_code": "GBR",
    "importance": 1,
    "pinyin_full": "lundun",
    "pinyin_initial": "ld"
  },
  {
    "name_en": "Vatican City",
    "name_zh": "梵蒂冈城",
    "lat": 41.9029,
    "lon": 12.4534,
    "country_code": "VAT",
    "importance": 1,
    "pinyin_full": "fandigangcheng",
    "pinyin_initial": "fdgc"
  },
  {
    "name_en": "Marseille",
    "name_zh": "马赛",
    "lat": 43.2965,
    "lon": 5.3698,
    "country_code": "FRA",
    "importance": 2,
    "pinyin_full": "masai",
    "pinyin_initial": "ms"
  },
  {
    "name_en": "Lyon",
    "name_zh": "里昂",
    "lat": 45.764,
    "lon": 4.8357,
    "country_code": "FRA",
    "importance": 2,
    "pinyin_full": "liang",
    "pinyin_initial": "la"
  },
  {
    "name_en": "Nice",
    "name_zh": "尼斯",
    "lat": 43.7102,
    "lon": 7.262,
    "country_code": "FRA",
    "importance": 2,
    "pinyin_full": "nisi",
    "pinyin_initial": "ns"
  },
  {
    "name_en": "Hamburg",
    "name_zh": "汉堡",
    "lat": 53.5511,
    "lon": 9.9937,
    "country_code": "DEU",
    "importance": 2,
    "pinyin_full": "hanbao",
    "pinyin_initial": "hb"
  },
  {
    "name_en": "Munich",
    "name_zh": "慕尼黑",
    "lat": 48.1351,
    "lon": 11.582,
    "country_code": "DEU",
    "importance": 2,
    "pinyin_full": "munihei",
    "pinyin_initial": "mnh"
  },
  {
    "name_en": "Frankfurt",
    "name_zh": "法兰克福",
    "lat": 50.1109,
    "lon": 8.6821,
    "country_code": "DEU",
    "importance": 2,
    "pinyin_full": "falankefu",
    "pinyin_initial": "flkf"
  },
  {
    "name_en": "Manchester",
    "name_zh": "曼彻斯特",
    "lat": 53.4808,
    "lon": -2.2426,
    "country_code": "GBR",
    "importance": 2,
    "pinyin_full": "manchesite",
    "pinyin_initial": "mcst"
  },
  {
    "name_en": "Edinburgh",
    "name_zh": "爱丁堡",
    "lat": 55.9533,
    "lon": -3.1883,
    "country_code": "GBR",
    "importance": 2,
    "pinyin_full": "aidingbao",
    "pinyin_initial": "adb"
  },
  {
    "name_en": "Cardiff",
    "name_zh": "加的夫",
    "lat": 51.4816,
    "lon": -3.1791,
    "country_code": "GBR",
    "importance": 2,
    "pinyin_full": "jiadefu",
    "pinyin_initial": "jdf"
  },
  {
    "name_en": "St. John's",
    "name_zh": "圣约翰",
    "lat": 17.1167,
    "lon": -61.85,
    "country_code": "ATG",
    "importance": 1,
    "pinyin_full": "shengyuehan",
    "pinyin_initial": "syh"
  },
  {
    "name_en": "Bridgetown",
    "name_zh": "布里奇敦",
    "lat": 13.1058,
    "lon": -59.6132,
    "country_code": "BRB",
    "importance": 1,
    "pinyin_full": "buliqidun",
    "pinyin_initial": "blqd"
  },
  {
    "name_en": "Belmopan",
    "name_zh": "贝尔莫潘",
    "lat": 17.4975,
    "lon": -88.1978,
    "country_code": "BLZ",
    "importance": 1,
    "pinyin_full": "beiermopan",
    "pinyin_initial": "bemp"
  },
  {
    "name_en": "San José",
    "name_zh": "圣何塞",
    "lat": 9.9281,
    "lon": -84.0907,
    "country_code": "CRI",
    "importance": 1,
    "pinyin_full": "shenghesai",
    "pinyin_initial": "shs"
  },
  {
    "name_en": "Havana",
    "name_zh": "哈瓦那",
    "lat": 23.1136,
    "lon": -82.3666,
    "country_code": "CUB",
    "importance": 1,
    "pinyin_full": "hawana",
    "pinyin_initial": "hwn"
  },
  {
    "name_en": "Roseau",
    "name_zh": "罗索",
    "lat": 15.2833,
    "lon": -61.3833,
    "country_code": "DMA",
    "importance": 1,
    "pinyin_full": "luosuo",
    "pinyin_initial": "ls"
  },
  {
    "name_en": "Santo Domingo",
    "name_zh": "圣多明各",
    "lat": 18.4861,
    "lon": -69.9312,
    "country_code": "DOM",
    "importance": 1,
    "pinyin_full": "shengduomingge",
    "pinyin_initial": "sdmg"
  },
  {
    "name_en": "San Salvador",
    "name_zh": "圣萨尔瓦多",
    "lat": 13.7942,
    "lon": -88.8967,
    "country_code": "SLV",
    "importance": 1,
    "pinyin_full": "shengsaerwaduo",
    "pinyin_initial": "ssewd"
  },
  {
    "name_en": "St. George's",
    "name_zh": "圣乔治",
    "lat": 12.05,
    "lon": -61.75,
    "country_code": "GRD",
    "importance": 1,
    "pinyin_full": "shengqiaozhi",
    "pinyin_initial": "sqz"
  },
  {
    "name_en": "Guatemala City",
    "name_zh": "危地马拉城",
    "lat": 14.6349,
    "lon": -90.5069,
    "country_code": "GTM",
    "importance": 1,
    "pinyin_full": "weidimalacheng",
    "pinyin_initial": "wdmlc"
  },
  {
    "name_en": "Tegucigalpa",
    "name_zh": "特古西加尔巴",
    "lat": 14.4974,
    "lon": -89.6239,
    "country_code": "HND",
    "importance": 1,
    "pinyin_full": "teguxijiaerba",
    "pinyin_initial": "tgxjeb"
  },
  {
    "name_en": "Kingston",
    "name_zh": "金斯敦",
    "lat": 17.975,
    "lon": -76.794,
    "country_code": "JAM",
    "importance": 1,
    "pinyin_full": "jinsidun",
    "pinyin_initial": "jsd"
  },
  {
    "name_en": "Managua",
    "name_zh": "马那瓜",
    "lat": 12.1522,
    "lon": -86.2683,
    "country_code": "NIC",
    "importance": 1,
    "pinyin_full": "managua",
    "pinyin_initial": "mng"
  },
  {
    "name_en": "Panama City",
    "name_zh": "巴拿马城",
    "lat": 8.9824,
    "lon": -79.5199,
    "country_code": "PAN",
    "importance": 1,
    "pinyin_full": "banamacheng",
    "pinyin_initial": "bnmc"
  },
  {
    "name_en": "Basseterre",
    "name_zh": "巴斯特尔",
    "lat": 17.2903,
    "lon": -62.7237,
    "country_code": "KNA",
    "importance": 1,
    "pinyin_full": "basiteer",
    "pinyin_initial": "bste"
  },
  {
    "name_en": "Castries",
    "name_zh": "卡斯特里",
    "lat": 14.0101,
    "lon": -60.987,
    "country_code": "LCA",
    "importance": 1,
    "pinyin_full": "kasiteli",
    "pinyin_initial": "kstl"
  },
  {
    "name_en": "Kingstown",
    "name_zh": "金斯敦",
    "lat": 13.156,
    "lon": -59.617,
    "country_code": "VCT",
    "importance": 1,
    "pinyin_full": "jinsidun",
    "pinyin_initial": "jsd"
  },
  {
    "name_en": "Port of Spain",
    "name_zh": "西班牙港",
    "lat": 10.643,
    "lon": -61.398,
    "country_code": "TTO",
    "importance": 1,
    "pinyin_full": "xibanyagang",
    "pinyin_initial": "xbyg"
  },
  {
    "name_en": "Buenos Aires",
    "name_zh": "布宜诺斯艾利斯",
    "lat": -34.6037,
    "lon": -58.3816,
    "country_code": "ARG",
    "importance": 1,
    "pinyin_full": "buyinuosiailisi",
    "pinyin_initial": "bynsals"
  },
  {
    "name_en": "La Paz / Sucre",
    "name_zh": "拉巴斯/苏克雷",
    "lat": -16.5,
    "lon": -68.15,
    "country_code": "BOL",
    "importance": 1,
    "pinyin_full": "labasi/sukelei",
    "pinyin_initial": "lbs/skl"
  },
  {
    "name_en": "Brasília",
    "name_zh": "巴西利亚",
    "lat": -15.7942,
    "lon": -47.8825,
    "country_code": "BRA",
    "importance": 1,
    "pinyin_full": "baxiliya",
    "pinyin_initial": "bxly"
  },
  {
    "name_en": "Santiago",
    "name_zh": "圣地亚哥",
    "lat": -33.4489,
    "lon": -70.6693,
    "country_code": "CHL",
    "importance": 1,
    "pinyin_full": "shengdiyage",
    "pinyin_initial": "sdyg"
  },
  {
    "name_en": "Bogotá",
    "name_zh": "波哥大",
    "lat": 4.711,
    "lon": -74.0721,
    "country_code": "COL",
    "importance": 1,
    "pinyin_full": "bogeda",
    "pinyin_initial": "bgd"
  },
  {
    "name_en": "Quito",
    "name_zh": "基多",
    "lat": -2.1894,
    "lon": -79.889,
    "country_code": "ECU",
    "importance": 1,
    "pinyin_full": "jiduo",
    "pinyin_initial": "jd"
  },
  {
    "name_en": "Georgetown",
    "name_zh": "乔治敦",
    "lat": 4.86,
    "lon": -58.93,
    "country_code": "GUY",
    "importance": 1,
    "pinyin_full": "qiaozhidun",
    "pinyin_initial": "qzd"
  },
  {
    "name_en": "Asunción",
    "name_zh": "亚松森",
    "lat": -25.2637,
    "lon": -57.5759,
    "country_code": "PRY",
    "importance": 1,
    "pinyin_full": "yasongsen",
    "pinyin_initial": "yss"
  },
  {
    "name_en": "Lima",
    "name_zh": "利马",
    "lat": -12.0464,
    "lon": -77.0428,
    "country_code": "PER",
    "importance": 1,
    "pinyin_full": "lima",
    "pinyin_initial": "lm"
  },
  {
    "name_en": "Paramaribo",
    "name_zh": "帕拉马里博",
    "lat": 3.864,
    "lon": -55.203,
    "country_code": "SUR",
    "importance": 1,
    "pinyin_full": "palamalibo",
    "pinyin_initial": "plmlb"
  },
  {
    "name_en": "Montevideo",
    "name_zh": "蒙得维的亚",
    "lat": -34.9011,
    "lon": -56.1645,
    "country_code": "URY",
    "importance": 1,
    "pinyin_full": "mengdeweidiya",
    "pinyin_initial": "mdwdy"
  },
  {
    "name_en": "Caracas",
    "name_zh": "加拉加斯",
    "lat": 10.4806,
    "lon": -66.9036,
    "country_code": "VEN",
    "importance": 1,
    "pinyin_full": "jialajiasi",
    "pinyin_initial": "jljs"
  },
  {
    "name_en": "Cayenne",
    "name_zh": "卡宴",
    "lat": 4.9382,
    "lon": -52.33,
    "country_code": "GUF",
    "importance": 1,
    "pinyin_full": "kayan",
    "pinyin_initial": "ky"
  },
  {
    "name_en": "Kingstown",
    "name_zh": "金斯敦",
    "lat": 12.305,
    "lon": -61.478,
    "country_code": "VCT",
    "importance": 1,
    "pinyin_full": "jinsidun",
    "pinyin_initial": "jsd"
  },
  {
    "name_en": "Andorra la Vella",
    "name_zh": "安道尔城",
    "lat": 42.5063,
    "lon": 1.5218,
    "country_code": "AND",
    "importance": 1,
    "pinyin_full": "andaoercheng",
    "pinyin_initial": "adec"
  },
  {
    "name_en": "Monaco",
    "name_zh": "摩纳哥",
    "lat": 43.7384,
    "lon": 7.4246,
    "country_code": "MCO",
    "importance": 1,
    "pinyin_full": "monage",
    "pinyin_initial": "mng"
  },
  {
    "name_en": "San Marino",
    "name_zh": "圣马力诺",
    "lat": 43.9356,
    "lon": 12.4473,
    "country_code": "SMR",
    "importance": 1,
    "pinyin_full": "shengmalinuo",
    "pinyin_initial": "smln"
  },
  {
    "name_en": "Vatican City",
    "name_zh": "梵蒂冈城",
    "lat": 41.9029,
    "lon": 12.4534,
    "country_code": "VAT",
    "importance": 1,
    "pinyin_full": "fandigangcheng",
    "pinyin_initial": "fdgc"
  },
  {
    "name_en": "Mexico City",
    "name_zh": "墨西哥城",
    "lat": 19.4326,
    "lon": -99.1332,
    "country_code": "MEX",
    "importance": 1,
    "pinyin_full": "moxigecheng",
    "pinyin_initial": "mxgc"
  },
  {
    "name_en": "Warsaw",
    "name_zh": "华沙",
    "lat": 52.2297,
    "lon": 21.0122,
    "country_code": "POL",
    "importance": 1,
    "pinyin_full": "huasha",
    "pinyin_initial": "hs"
  },
  {
    "name_en": "Kyiv",
    "name_zh": "基辅",
    "lat": 50.4501,
    "lon": 30.5234,
    "country_code": "UKR",
    "importance": 1,
    "pinyin_full": "jifu",
    "pinyin_initial": "jf"
  }
]
